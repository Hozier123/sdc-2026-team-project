# R08-CONTRACT-v0.1 前端消费审核回执（Ye）

日期：2026-11-01。口径：**CODE_ONLY / 离线工件审核**，无真实联调结论。

## 收件与哈希

- 文件：R08_CONTRACT_v0.1_REVIEW_20261101.zip（95,950 字节，微信临时附件）
- 实核 SHA-256：`5c18e25c6eaa6b1b8df84ab17211a0df379d884e4327c1e6ae53795f2dd8605d`
- 内部 SHA256SUMS.txt：36/36 文件哈希全部核对通过（解包时中文文件名为 GBK 编码，按 cp937→GBK 解码恢复，字节内容不受影响）
- 用途：R08 候选与问题接口约定 v0.1 草案 + 18 份 INTERFACE_SAMPLE / NOT_LIVE 样例的正式消费审核

## 独立复核项（非采信包内 VALIDATION.json，全部本地重跑）

1. `reference/frontend/` 四文件与 4f95dd8 提交版逐字节一致（`git show 4f95dd8:<path>` 比对）。注意：4f95dd8 指提交版；R10 worktree 另有未提交本地实现（orders.tsx +110 行、新增 issueCopy.ts、review.css），见"发现 C"。
2. 18 份样例独立结构断言全部通过：枚举合法（DraftStatus/IssueCode/IssueReasonCode/ConditionKind/AskWho/AllowedAction/MatchSource）；`blocking_issues` == 开放（blocking 且未 resolved）问题 code 去重集合；`conditions` 为 issues 的 CUSTOMER_CONDITION 一致子集；SkuCandidate.tier_unit_price 均非空且符合两位小数 DecimalString；所有 span/field_evidence 坐标按 code point 回切 `masked_message` 全部吻合；未解决阻断时 allowed_actions 不含 APPROVE_AND_GENERATE_DO / SUBMIT_FOR_OWNER / OWNER_APPROVE 且 blocked_actions 给出原因；save_request 行均恰含 line_id/client_line_ref 之一，手工行 match_source=MANUAL_SELECTED；无 DO。
3. TypeScript wire 校验独立复跑：用 R10 worktree 的 tsc（`--noEmit --strict --target ES2022 --moduleResolution bundler --module ESNext`）对 `samples.typecheck.ts`（`satisfies S["OrderDraft"][]` / `S["SaveLinesRequest"][]` 严格标注）——**exit 0**，与 FRONTEND_TYPECHECK.json 结论一致。
4. 六场景语义抽查与草案 §4 一致：未知（空候选+UNKNOWN_PRODUCT 阻断）、多规格（两候选完整保留+MULTIPLE_PACK_SIZES）、缺单位（uom=null+MISSING_UOM/FIELD_NOT_EVIDENCED）、缺数量（不建普通行，issue.line_id=null）、缺价（见下）、条件目标（resolutions 结构含目标/UNIT/价/note）。after_manual 样例的 `expected_version`（=1）与 draft.version（=2）差异为正确语义：save_request 记录的是产生当前版本的请求。
5. 第 5 节缺价表达：`data_used` 在 gate0 中为开放 map（`{[key:string]: unknown}`），追加 r08 键**不需要改 gate0、不新增枚举**——与草案声明相符。缺价三样例自洽：blocked（sku_id=null、candidate_skus=[]、价/小计 null、r08 诊断完整、阻断）、after_manual（人工选 SKU 后保存仍拒，version 维持 1，仍阻断）、negative（override 不能补缺价）。

## 消费审核结论

**CONSUMABLE_WITH_MODIFICATIONS：wire 层可消费，样例结构可信（INTERFACE_SAMPLE/NOT_LIVE 口径内）；第 5 节缺价表达在 schema 上可承载，但当前 UI 未渲染，需 R10 实现（见下）。R08 冻结/结项仍 PENDING，本回执不代 Zhou 语义验收。**

## 发现与修改点

- **A（中）condition_id 不符合文档推导**：条件样例用占位值 `SAMPLE_C01`，而 gate0 Issue 注明应为 `CND_ + SHA-256(UTF-8(draft_id|condition_kind|span_start|span_end))[:24].upper()`（本包实测应为 `CND_6BAFF2E046E11A9F84B97079`）。前端不校验该格式（types.ts:118 仅透传，demo.ts:748 亦用随机 UUID），不影响前端消费；但作为契约样例应按文档规则生成，或在 §6 样例注意事项中显式注明偏差，避免样例与 schema 注释矛盾。
- **B（低）deprecated 字段依赖**：样例 issue 携带 `source_span`（gate0 标注 @deprecated，"v1.3 前端迁移后移除"）。建议 R09 实现与后续样例以 `span` 为主，`source_span` 仅作兼容回退，勿让新链路长期依赖 deprecated 键。
- **C（提示）快照口径**：He 的 reference 为 4f95dd8 提交版，与 Ye 指定 ref 一致，无错；但 R10 的实际展示逻辑在 worktree 未提交本地代码中（同为未渲染 data_used.r08），第 5 节 UI 结论不受影响。

## R10 展示方式与必要修改（回应草案 §5 提问）

现状确认：data_used.r08 任意键当前 UI **不会自动展示**（He 判断正确）。缺价行会命中 issueCopy 的 NO_CANDIDATE 通用文案 "No product option was returned…"——对缺价场景是误导（兼容 SKU 存在，只是等级价未配置且可选集被刻意保留不发）。tier_unit_price=null 显示 "—"。

R10 需做（当前未实现，属待办清单，不把"schema 可承载"当"UI 已支持"）：

1. 新增 r08 诊断类型收窄访问器，从 `issue.data_used.r08` 安全读 problem_kind / explanation / identity_candidates / selectable。
2. 检查卡：`problem_kind === "MISSING_TIER_PRICE"` 时以 explanation 替代通用 NO_CANDIDATE 文案，并给缺价专属标题。
3. 只读身份候选摘要：display_name / pack_size / grade / base_unit / available_qty，tier_unit_price=null 显示 "Not configured"；**不可点选**（selectable=false），不进入 candidate-grid。
4. 保存返回 HTTP 422 / MISSING_TIER_PRICE 时给明确文案（error_code 已在 gate0 ErrorCode 枚举，无需契约变更）。
5. 兼容性：无 gate0 / 枚举改动，wire.ts 归一化对 data_used 透传无破坏。

## 限制声明

本审核为源码与离线样例工件检查；未连接 API/数据库/模型，无运行时行为验证，无 E 项结论。R07 仍 TESTED_OFFLINE / LIVE_UNVERIFIED；样例中 ai_mode=FALLBACK 仅为枚举形状占位，不作为真实模式证据。
