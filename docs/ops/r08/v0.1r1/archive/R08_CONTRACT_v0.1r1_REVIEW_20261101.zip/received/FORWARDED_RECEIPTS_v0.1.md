# 用户转交回执登记

来源：本聊天用户于 2026-11-01 转交的三段回复。以下为内容登记，不伪装为各责任人的独立原件或本稿的新签字。

## Zhou

已确认 R08 可先开展，无须等待 R07 真实模型；范围锁定 GULA/BERAS/GARAM，不含 TELUR/S03。六类语义与用户转交原话一致，详列本稿第 4 节。要求每类阻断、人工处理后、负例，标 INTERFACE_SAMPLE / NOT_LIVE，包含 issues/candidate_skus/blocking_issues/allowed_actions/blocked_actions；未解决批准不可用且后端应拒绝，无 DO／库存变化，人工来源及版本可追踪。不得冒充 E 项或泄露 R05 私有答案。

提到完整文件 R08_ZHOU_SEMANTICS_CONFIRMATION_2026-11-01.md，但本轮未附该原件；本次只登记用户转交内容，不声称已核该文件哈希。Zhou 尚未对本轮新编 R08 v0.1 样例作验收。

## Xiong

已收到原附件 R07_FIELD_CONTRACT_2026-11-01.md，完整 SHA-256 06290c423b5514e757d820d13c05140f9fcbbe322761c91ec66217cd42587c90，实际匹配；原字节复制至本目录，未改写。

R07-FIELD-v0.1 基于 a34f3d2 / f347ed6，R06 v001/r2，TESTED_OFFLINE；无 live/P-2。未确定项保留：无条件 target IDs、scope 简化、无 family FieldEvidence、ignored_spans 可为 -1、C8 未闭合、无真实模型 JSON。请求 He 确认 R08 接 pre-resolver 还是最终 API，本稿第 1 节已给明确选择，待其接收回执。

## Ye

回执为 CODE_ONLY，核对 R10 worktree codex/r10-review-20261101 / 4f95dd8 的 gate0.generated.ts、wire.ts、types.ts、orders.tsx；不是联调结果。允许字段及限制见用户原消息。本轮通过 GitHub 连接器按 ref 4f95dd8 读取到同四文件，快照保存在 reference/frontend/；读取不表示修改或发布。

关键限制已纳入草案：封闭枚举、候选价 DecimalString、只读 tier 价、条件 PRICE 确认目标及 UNIT 口径、缺数量手工行、code point 偏移、expected_version、仓库响应独立严格白名单。Ye 明确“草案和示例响应发来后做正式审核”，因此审核状态仍 PENDING。
