# R07 字段约定与离线交接（v0.1）

- 时间：2026-11-01（UTC+8）
- 代码版本：本地 `feat/r07-catalog-prompt` / commit `a34f3d2`，基于 `f347ed6`
- 数据版本：R06 `TRILINGUAL-2026-10-31-v001 / r2`；候选已 LOADED
- 状态：`TESTED_OFFLINE`；无 live、无真实模型 JSON、无 P-2
- 性质：接口兼容性草案，不是 R07 验收，不是 R08 已实现，不是 R05 证据

## 一、边界先说清

R07 不产生 `draft_id`、`sku_id`、候选 SKU、价格、库存、审批、DO 或 blocking 结果。当前有两层可交接对象：

1. **AI → 后端 pre-resolver 边界**：`AdapterLine` / `RawRow` 与 `ExtractedCondition`。R07 实际负责这一段。
2. **后端 → R08/API 边界**：`OrderDraftResponse` 的 `WorkingLine` / `Issue`。这些字段由 parse/resolver 生成，R07 不拥有，R08 不应从原始模型 JSON 反推。

**R08 的确切接口范围尚未在现有执行材料中定义。** 本文件同时列出两层字段；R08 若要接候选/问题展示，应以第 2 层为准，若只接抽取结果则用第 1 层。请 He 确认采用哪一层。

## 二、原始模型行 `LlmRow`

代码：`backend/app/ai/prompt.py:18-40`；sanitize：`backend/app/ai/extractor.py:249-297`。该层只用于审计，不建议 R08 直接绑定。

| 字段 | 类型 | 必填 | 可空 | 规则 |
|---|---|---|---|---|
| `span` | string | 提示词要求必填 | 否 | 提示词要求为 `masked_text` 的 verbatim substring；sanitize 只 `strip`，空串/错 span 由后续 adapter 标 `SOURCE_EVIDENCE_INVALID` |
| `fam` | string | 必填 | 否 | 必须是当前 tenant family 白名单 ID 或 `UNKNOWN`；空白/目录外统一改为 `UNKNOWN` |
| `qty` | int／ASCII 数字 string／null | 可空 | 是 | 最终 sanitize 为 1..999999 的正整数；bool、0、负数、小数、非 ASCII 数字均变 null；不静默截断 |
| `uom` | string／null | 可空 | 是 | 只是模型候选；adapter 会用 H1 重新取证，无证据则变 null 并记 issue |
| `pack_size` | string／null | 可空 | 是 | 只是模型候选；必须是原文中有证据的规格；不把 `1kg` 混进 qty |
| `conds` | list[string] | 否，默认 `[]` | 否（数组本身） | 模型候选条件；**不是最终条件来源**，最终条件由 H5 独立产生 |
| `ignored_spans` | list[string]（顶层） | 否，默认 `[]` | 否（数组本身） | 模型忽略片段；adapter 会补 PII mask token |

## 三、Adapter／RawRow 边界

代码：`backend/app/ai/adapter.py:70-119`、`backend/app/extraction/runpod_adapter.py:50-82`、`backend/app/extraction/base.py:10-30`。

### 3.1 `AdapterLine`

| 字段 | 类型 | 必填 | 可空 | 说明 |
|---|---|---|---|---|
| `line_id` | string | 是 | 否 | 当前为 `LINE_{index}`，只在本次响应内稳定，不是数据库 line id |
| `span` | string | 是 | 否 | adapter 定位后的原文 span |
| `span_start` | int | 是 | 否 | `masked_text` 的 Unicode code point；invalid 时可为 0 |
| `span_end` | int | 是 | 否 | 同上；invalid 时可为 0 |
| `family_id` | string | 是 | 否 | R07 adapter 路径始终为 family ID 或 `UNKNOWN`，不是 null |
| `qty` | int／null | 否 | 是 | H1 复核后的正整数；无效/不匹配为 null |
| `uom` | string／null | 否 | 是 | canonical unit 或 null；无证据不补 |
| `pack_size` | string／null | 否 | 是 | 原文证据后的规格或 null |
| `field_evidence` | list[FieldEvidence] | 是（可为空列表） | 否 | qty／uom／pack_size 的坐标证据；当前不包含 family 证据 |
| `match_source` | string | 是 | 否 | `LLM_EXTRACTED` 或 `RAPIDFUZZ_FALLBACK`；schema 另有 `SUGGESTED_DEFAULT`、`MANUAL_SELECTED`，但 R07 adapter 不产生它们 |
| `issue_code` | string／null | 否 | 是 | 当前 `LOW_CONFIDENCE_MATCH` 或 null |
| `reason_code` | string／null | 否 | 是 | 如 `FIELD_NOT_EVIDENCED`、`FAMILY_NOT_EVIDENCED`、`SOURCE_EVIDENCE_INVALID`、`OVERLAPPING_SPAN` |
| `model_coerced` | bool | 是，默认 false | 否 | 模型给 ASCII 数字字符串被转成 int 时标记 |

### 3.2 `FieldEvidence`

```text
field: "qty" | "uom" | "pack_size"
raw_text: string                  # 必须等于 masked_text[start:end]
start: int                        # Unicode code point，>=0
end: int                          # Unicode code point，> start
normalizer_version: string        # 当前 "field-evidence-v2"
```

`family` 证据目前**不在** `field_evidence` 中；family 通过 adapter 的 catalog phrase 校验和 backend guard 证明。R08 若要求“每个字段都有证据”，需另加 family evidence 字段——当前没有。

### 3.3 `RawRow`

来自 `runpod_adapter.adapter_output_to_raw`：

| 字段 | 类型 | 可空 | 说明 |
|---|---|---|---|
| `span` | string | 否 | 原文 span |
| `qty` | int／null | 是 | 同 AdapterLine |
| `uom` | string／null | 是 | 同 AdapterLine |
| `fam` | string／null | R07 路径否 | R07 adapter 输出为字符串；通用 dataclass 允许 null，但 R08 不应接受 null family |
| `pack_size` | string／null | 是 | 同 AdapterLine |
| `conds` | tuple[dict] | 否，可为空 | 仅包含 span 落在该 row span 内的 H5 条件 |
| `source` | string | 否 | 同 `match_source` |
| `invalid_reason` | string／null | 是 | 无效行来源 |
| `memory` | bool | 否，默认 false | R07 路径为 false；R08 不应把 memory 当 R07 输出 |
| `alias` | dict／null | 是 | R07 路径为 null |
| `field_evidence` | tuple[dict] | 否，可为空 | 同 AdapterLine 的 FieldEvidence 序列化 |

### 3.4 `RawExtraction`

| 字段 | 类型 | 可空 | 说明 |
|---|---|---|---|
| `rows` | tuple[RawRow] | 否 | 每次响应的行 |
| `ignored_spans` | tuple[dict] | 否 | `{text,start,end,normalizer_version}`；若无法定位，`start/end` 可为 -1；R08 必须接受这个哨兵值或显式丢弃 |
| `ai_mode` | string／null | 是（R07 实际非空） | `LLM`／`FALLBACK`／`MIXED`／`ALIAS_ONLY`；**必须原样记录**，不能由页面结果反推 |
| `conditions` | tuple[dict] | 否 | 全文的 H5 条件列表，含未落在任何 row span 的条件 |

## 四、条件与目标行

### 4.1 当前条件字段

代码：`backend/app/ai/adapter.py:100-111,209-326`；转换：`runpod_adapter.py:19-82`。

| 字段 | 类型 | 必填 | 可空 | 说明 |
|---|---|---|---|---|
| `kind` | string | 是 | 否 | 当前 H5 实际产生 `STOCK`／`PRICE`／`OTHER`；`TIME_OR_OTHER` 被映射为 `OTHER`，不要依赖 `TIME` |
| `span` | string | 是 | 否 | 条件原文片段 |
| `start` | int | 是 | 否 | `masked_text` code point |
| `end` | int | 是 | 否 | 同上 |
| `condition_scope` | string | 是 | 否 | 当前 P0：只有一条 line 时为 `SINGLE_LINE`，否则 `UNKNOWN`；`MULTI_LINE`／`ORDER_LEVEL` 并不稳定产生 |
| `price_basis` | string／null | PRICE 时有 | 是 | 当前 H5 只产生 `UNIT` 或 `UNKNOWN`，不产生 `TOTAL` |
| `requested_amount` | decimal string／null | 否 | 是 | 如 `"90"`、`"12.50"`；不存 float |

### 4.2 关联规则

- `AdapterOutput.conditions` 是**全局列表**，没有显式 `line_id`／`target_line_ids`。
- `adapter_output_to_raw` 会把 `condition.span in line.span` 的条件放进该 `RawRow.conds`；同时完整条件仍保留在 `RawExtraction.conditions`。
- parse 之后才根据行 span 和条件 span 计算目标行；只有一个匹配行或只有一个总行时可得 `Issue.line_id`，否则目标为 `null`，见 `parse.py:158-218,348-390`。
- **未确定项：R07 没有条件目标行 ID。** 如果 R08 需要稳定的 `target_line_ids`，必须在后端 issue 层增加，不应假设 `RawRow.conds` 是完整的条件→行映射。
- 条件可能出现在候选行之外（订单级/多行），只存在 `RawExtraction.conditions`；R08 不能只看行内 `conds` 就漏掉它。

## 五、R08 若接最终 API

最终 `OrderDraftResponse` 由 parse/resolver 生成，代码 `backend/app/schemas.py:97-205`；R07 不产生这些字段。R08 展示候选/问题建议绑定以下字段：

- `WorkingLine`：`line_id`、`family_id`、`sku_id`（可空）、`requested_qty`、`uom`、`pack_size`、`source_span`、`span_start/end`、`field_evidence`、`match_source`、`candidate_skus`、`available_qty`。
- `Issue`：`issue_id`、`code`、`line_id`、`candidate_line_ids`、`target_line_ids`、`span`、`span_start/end`、`condition_id`、`condition_kind`、`condition_scope`、`requested_unit_price`、`price_basis`、`blocking`、`resolved`。
- `candidate_skus`、价格、库存、blocking、DO、审批均为 resolver／backend 结果，不属于 R07 输出。

## 六、脱敏 schema 示例（不是模型输出、不是 R05 证据）

输入：

```text
2 bag 食盐 1kg
2 bag Gula 2kg, kalau RM90 boleh?
```

示意 `RawExtraction`（坐标按该 message 计算；仅 schema 演示）：

```json
{
  "rows": [
    {
      "span": "2 bag 食盐 1kg",
      "fam": "FAM_GARAM",
      "qty": 2,
      "uom": "bag",
      "pack_size": "1kg",
      "conds": [],
      "source": "LLM_EXTRACTED",
      "invalid_reason": null,
      "memory": false,
      "alias": null,
      "field_evidence": [
        {"field": "qty", "raw_text": "2", "start": 0, "end": 1, "normalizer_version": "field-evidence-v2"},
        {"field": "uom", "raw_text": "bag", "start": 2, "end": 5, "normalizer_version": "field-evidence-v2"},
        {"field": "pack_size", "raw_text": "1kg", "start": 9, "end": 12, "normalizer_version": "field-evidence-v2"}
      ]
    },
    {
      "span": "2 bag Gula 2kg, kalau RM90 boleh?",
      "fam": "FAM_GULA",
      "qty": 2,
      "uom": "bag",
      "pack_size": "2kg",
      "conds": [
        {
          "kind": "PRICE",
          "span": "kalau RM90",
          "start": 29,
          "end": 39,
          "condition_scope": "UNKNOWN",
          "price_basis": "UNKNOWN",
          "requested_amount": "90"
        }
      ],
      "source": "LLM_EXTRACTED",
      "invalid_reason": null,
      "memory": false,
      "alias": null,
      "field_evidence": [
        {"field": "qty", "raw_text": "2", "start": 13, "end": 14, "normalizer_version": "field-evidence-v2"},
        {"field": "uom", "raw_text": "bag", "start": 15, "end": 18, "normalizer_version": "field-evidence-v2"},
        {"field": "pack_size", "raw_text": "2kg", "start": 24, "end": 27, "normalizer_version": "field-evidence-v2"}
      ]
    }
  ],
  "ignored_spans": [],
  "ai_mode": "LLM",
  "conditions": [
    {
      "kind": "PRICE",
      "span": "kalau RM90",
      "start": 29,
      "end": 39,
      "condition_scope": "UNKNOWN",
      "price_basis": "UNKNOWN",
      "requested_amount": "90"
    }
  ]
}
```

注意：示例中的坐标只为展示字段结构；真实值必须由 adapter 对实际 `masked_text` 生成并逐项回切验证。

## 七、未确定项（必须标出）

1. **R08 的准确接口边界未定义**：现有材料没有说明 R08 是接 pre-resolver 还是最终 API；本文件两种都列出，请 He 确认。
2. **条件目标行 ID 不存在于 R07**：当前靠 span 包含关系和 parse 计算；R08 若要求稳定 `target_line_ids`，需要后端新增。
3. **`condition_scope` 是 P0 简化**：多行／订单级条件不能保证 `MULTI_LINE`／`ORDER_LEVEL`；当前 H5 不产生 `TIME`、`TOTAL`。
4. **family 无 FieldEvidence**：`field_evidence` 只有 qty／uom／pack_size；family 证据在 adapter/guard 内部。
5. **`ignored_spans` 坐标可能为 -1**：`runpod_adapter._ignored_span_dict` 找不到原文时保留哨兵值；R08 是否允许 -1 需约定。
6. **`RawRow.fam` dataclass 类型可空**：R07 路径实际非空，但其他 provider 可能为空；R08 应以最终 `WorkingLine.family_id` 为准。
7. **C-8 未闭合**：R05 短输入预算足够；4,000 个中文字符加 2,048 输出超过 8,192，端点 tokenizer 仍未捕获；R08 不得把满 4,000 输入当已支持。
8. **无 live 证据**：R07 仍 `TESTED_OFFLINE`；没有真实模型 JSON、`actual_ai_mode=LLM`、P-2。

## 八、版本与接收

- 约定版本：`R07-FIELD-v0.1`（基于 `a34f3d2`，离线草案）
- 代码补丁：`8abc8f3b…17844`（10,314 B）
- R07 状态：`TESTED_OFFLINE / LIVE_UNVERIFIED`
- 接收方：He（R08）；语义验收：Zhou；技术证据：Xiong；R07 不得据此写成已验收。
