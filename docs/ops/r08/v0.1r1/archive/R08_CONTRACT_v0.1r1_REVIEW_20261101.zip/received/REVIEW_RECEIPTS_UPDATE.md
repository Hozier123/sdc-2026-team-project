# v0.1 正式审核及 v0.1r1 修订来源

本轮来源：用户转交的 Ye、Xiong、Zhou 消息及 Ye 原附件。以下登记不伪装为未提供的原文件。

## Ye

原附件原始名 Ye_消费审核回执_20261101.md，保存为 YE_CONSUMPTION_REVIEW_20261101.md，字节未改。完整 SHA-256 a21b4aa74c7386053bb2e4ea7400be54ee0d541e6a7efb64feaaa5155397bea2 已匹配。

结论 CONSUMABLE_WITH_MODIFICATIONS，CODE_ONLY；18 样例、前端四快照及 tsc 为其独立复核。A 条件 ID 用占位、B Issue.source_span deprecated、C 固定提交版与未提交 worktree 差别已纳入本次修订。R10 五项展示待办仍未实现，没有 live 联调。

其原文关于 R07 LIVE_UNVERIFIED 是收到时的历史口径，按后续 Xiong 转交更正补充，不改回执原字节。

## Xiong（用户转交，未附独立回执／preflight v2 原件）

核原包 36 项清单和 R07 字段原件；确认 v0.1 第 1–2 节边界及原限制可接收。唯一异议：03:28 已有一次真实候选 preflight（v2 证据，P-2 仍未签），应记“R07 TESTED_OFFLINE + one live preflight observed (v2 evidence; P-2 not signed)”。要求更正草案／状态后再冻结 v0.1。

本次已更正新稿和状态文件；未独立复核 v2 实测内容，不签 R07 验收、P-2、语义 PASS。接口边界无变化，原接收结论保留。

## Zhou（用户转交，未附独立审核原件）

合同语义 PASS；样例 PASS_WITH_CONDITIONS，限接口样例；其 Pydantic 18/18、不变式 0 错，前端 tsc 未独立重跑，采信 He 的记录并保留限制。缺价恢复口径明确认可。

冻结前 P3：① missing_price_after_manual 机器可读保存拒绝及版本结果；② NO_CANDIDATE 兼容占位必须用缺价诊断分流，不能消费则另评专用码；③ ask=SYSTEM 下 clerk 入口与授权配置分工，入口不可见可改 CLERK 或两段式。另建议统一负例 expected。均已在 v0.1r1 落实为修订工件，待 Ye／Zhou 核补件闭合，未代签最终结论。

## 原包编码复核

He 检查本地原 ZIP：中文条目具有 ZIP UTF-8 标志，原包哈希仍为 5c18e25c6eaa6b1b8df84ab17211a0df379d884e4327c1e6ae53795f2dd8605d。Ye 报告的解包转码现象按其收件环境原话保留，不据此改原包或原回执。为规避跨平台工具差异，本次修订归档仅使用 ASCII 路径，内容 UTF-8，并重新验证所有清单哈希。
