"""Build explicitly synthetic R08 review examples. Never connects to an API/DB."""
from __future__ import annotations

import copy
import hashlib
import json
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STAMP = "2026-11-01T03:30:00+08:00"  # synthetic wire timestamp, not an execution timestamp


def write(path, value):
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", "utf-8")


def candidate(sku, family="GULA", pack="1kg", price="7.10"):
    return dict(sku_id="SAMPLE_" + sku, family_id="FAM_" + family,
                display_name="Interface sample " + sku, pack_size=pack, grade=None,
                base_unit="bag", tier_unit_price=price, available_qty=30)


A = candidate("GULA_1KG")
B = candidate("GULA_2KG", pack="2kg", price="13.20")
R = candidate("BERAS_5KG", "BERAS", "5kg", "21.30")
S = candidate("GARAM_1KG", "GARAM", price="4.60")


def line(message, span, family="GULA", selected=None, candidates=(), qty=2,
         uom="bag", pack=None, line_id="SAMPLE_L01"):
    start = message.index(span)
    price = selected["tier_unit_price"] if selected else None
    evid = []
    # Evidence records contain only literal input fragments, never confirmed values.
    for field, text in [("qty", str(qty)), ("uom", uom), ("pack_size", pack)]:
        if text and text in span:
            a = start + span.index(text)
            evid.append(dict(field=field, raw_text=text, start=a, end=a + len(text),
                             normalizer_version="field-evidence-v2"))
    return dict(line_id=line_id, client_line_ref=None,
                sku_id=selected["sku_id"] if selected else None,
                family_id="FAM_" + family if family != "UNKNOWN" else "UNKNOWN",
                description=selected["display_name"] if selected else span,
                requested_qty=qty, confirmed_qty=None, effective_qty=qty,
                uom=uom, pack_size=pack, grade=None,
                tier_unit_price=price, unit_price_override=None, override_reason=None,
                effective_unit_price=price,
                subtotal_rm=format(Decimal(price) * qty, ".2f") if price else None,
                match_source="RAPIDFUZZ_FALLBACK", source_span=span,
                span_start=start, span_end=start + len(span), field_evidence=evid,
                candidate_skus=list(candidates), saved_alias=None,
                available_qty=30 if selected else None)


def issue(message, span, code, reason=None, line_id="SAMPLE_L01", **extra):
    start = message.index(span)
    value = dict(issue_id="SAMPLE_I01", code=code, line_id=line_id,
                 span=span, span_start=start, span_end=start + len(span),
                 candidate_line_ids=[], target_line_ids=[], reason_code=reason,
                 ask="CLERK", data_used={}, blocking=True, resolved=False,
                 resolution=None, resolution_note=None, auto_resolved_by=None)
    value.update(extra)
    return value


def draft(name, message, lines, issues, version=1):
    draft_id = "SAMPLE_R08_" + name.upper()
    for item in issues:
        if item["code"] == "CUSTOMER_CONDITION":
            material = f"{draft_id}|{item['condition_kind']}|{item['span_start']}|{item['span_end']}"
            item["condition_id"] = "CND_" + hashlib.sha256(material.encode("utf-8")).hexdigest()[:24].upper()
    blocking = sorted({i["code"] for i in issues if i["blocking"] and not i["resolved"]})
    complete = bool(lines) and all(l["subtotal_rm"] is not None for l in lines)
    total = format(sum(Decimal(l["subtotal_rm"]) for l in lines), ".2f") if complete else None
    return dict(draft_id=draft_id, version=version,
                status="DISAMBIGUATION_REQUIRED" if blocking else "READY_FOR_APPROVAL",
                customer_id="SAMPLE_CUSTOMER", customer=dict(customer_id="SAMPLE_CUSTOMER",
                name="Interface sample customer", tier="A", credit_flag="NONE",
                has_credit_notice=False, phone_e164=None),
                masked_message=message, ai_mode="FALLBACK", lines=lines, issues=issues,
                conditions=[i for i in issues if i["code"] == "CUSTOMER_CONDITION"],
                blocking_issues=blocking, escalation_preview=[],
                totals=dict(order_total=total, currency="MYR", is_complete=complete),
                allowed_actions=["EDIT_DRAFT", "RESOLVE_ISSUE", "CANCEL_DRAFT", "VIEW_ACTIVITY"]
                if blocking else ["EDIT_DRAFT", "APPROVE_AND_GENERATE_DO", "CANCEL_DRAFT", "VIEW_ACTIVITY"],
                blocked_actions={k: blocking for k in ["APPROVE_AND_GENERATE_DO", "SUBMIT_FOR_OWNER", "OWNER_APPROVE"]}
                if blocking else {}, clarification_draft=None, clarification_lang=None,
                ignored_spans=[], disambiguations=[], termination_reason=None,
                terminated_by_user_id=None, termination_note=None,
                created_at=STAMP, updated_at=STAMP, do_number=None)


def manual_input(l, product, *, qty=None, uom="bag", new=False):
    return dict(**({"client_line_ref": "SAMPLE_MANUAL_01"} if new else {"line_id": l["line_id"]}),
                sku_id=product["sku_id"], family_id=product["family_id"],
                confirmed_qty=qty or l["requested_qty"], uom=uom,
                pack_size=product["pack_size"], grade=product["grade"],
                match_source="MANUAL_SELECTED", save_to_alias_cache=False, alias_scope="CUSTOMER")


def after_manual(before, product, *, qty=2, new=False):
    out = copy.deepcopy(before)
    out["version"] += 1
    if new:
        l = line(out["masked_message"], out["masked_message"], "GARAM", selected=product,
                 qty=qty, uom=None, pack="1kg")
        l["field_evidence"] = [e for e in l["field_evidence"] if e["field"] == "pack_size"]
        out["lines"] = [l]
    l = out["lines"][0]
    l.update(sku_id=product["sku_id"], family_id=product["family_id"],
             description=product["display_name"], confirmed_qty=qty, effective_qty=qty,
             uom="bag", pack_size=product["pack_size"], tier_unit_price=product["tier_unit_price"],
             effective_unit_price=product["tier_unit_price"],
             subtotal_rm=format(Decimal(product["tier_unit_price"]) * qty, ".2f"),
             match_source="MANUAL_SELECTED", candidate_skus=[], available_qty=30)
    if new:
        l["client_line_ref"] = "SAMPLE_MANUAL_01"
        l["requested_qty"] = qty  # manual row quantity, never claimed as original extraction
    # Non-condition issues are recomputed on save, not resolved with ResolutionChoice.
    out.update(issues=[], conditions=[], disambiguations=[], blocking_issues=[],
               status="READY_FOR_APPROVAL", blocked_actions={},
               allowed_actions=["EDIT_DRAFT", "APPROVE_AND_GENERATE_DO", "CANCEL_DRAFT", "VIEW_ACTIVITY"])
    out["totals"] = dict(order_total=l["subtotal_rm"], currency="MYR", is_complete=True)
    return out


def save_expectation(response, request, expected_http_status=200, error_code=None):
    return dict(http_status=expected_http_status, error_code=error_code,
                actual_result="NOT_RUN", actual_http_status=None,
                draft_version_before=request["expected_version"],
                draft_version_after=response["version"],
                stored_draft_behavior="UNCHANGED" if expected_http_status >= 400 else "NEW_SAVED_VERSION")


def envelope(category, phase, response, *, request=None, negative=None, notes=""):
    return dict(sample_id=category + "_" + phase, contract_version="R08-CONTRACT-v0.1r1", classification="INTERFACE_SAMPLE",
                execution_mode="NOT_LIVE", source="HAND_AUTHORED_SYNTHETIC",
                ai_mode_provenance="REQUIRED_WIRE_ENUM_PLACEHOLDER_NOT_OBSERVED",
                catalog_provenance="SYNTHETIC_WITHIN_FAM_GULA_BERAS_GARAM",
                runtime_execution_status="NOT_RUN", phase=phase, notes=notes,
                draft=response, save_request=request,
                save_expectation=save_expectation(response, request,
                    expected_http_status=422 if category == "missing_price" else 200,
                    error_code="MISSING_TIER_PRICE" if category == "missing_price" else None)
                    if request is not None else None,
                negative_example=negative,
                approval_expectation=dict(execution_status="NOT_RUN",
                    expected_if_unresolved=dict(http_status=400, error_code="DISAMBIGUATION_UNRESOLVED")
                    if response["blocking_issues"] else None,
                    approval_performed=False, actual_http_status=None),
                side_effects=dict(evidence_kind="ILLUSTRATIVE_ONLY", database_contacted=False,
                    do_created=False, inventory_read=False, inventory_written=False,
                    actual_inventory_before=None, actual_inventory_after=None))


def negative_action(kind, request, http_status, error_code, behavior):
    return dict(kind=kind, request=request,
                expected=dict(http_status=http_status, error_code=error_code, behavior=behavior,
                              draft_version_after=1, do_created=False, inventory_mutation=False),
                actual_result="NOT_RUN", actual_http_status=None)


def main():
    samples = []
    m = "2 bag gula misteri"
    unknown = draft("unknown", m, [line(m, m, "UNKNOWN")],
                    [issue(m, m, "LOW_CONFIDENCE_MATCH", "UNKNOWN_PRODUCT")])
    m = "2 bag sugar"
    ambiguous = draft("ambiguous", m, [line(m, m, candidates=(A, B))],
                      [issue(m, m, "MULTIPLE_PACK_SIZES")])
    m = "2 Beras 5kg"
    uom = draft("missing_uom", m, [line(m, m, "BERAS", candidates=(R,), uom=None, pack="5kg")],
                [issue(m, m, "MISSING_UOM", "FIELD_NOT_EVIDENCED")])
    m = "Garam 1kg"
    qty = draft("missing_qty", m, [], [issue(m, m, "LOW_CONFIDENCE_MATCH", "INVALID_QUANTITY", line_id=None,
        data_used={"r08": {"problem_kind": "MISSING_QUANTITY", "family_id": "FAM_GARAM",
                           "requested_qty": None, "pack_size": "1kg", "recovery": "MANUAL_ADD_LINE"}})])
    cases = [("unknown", unknown, A), ("multiple_variants", ambiguous, B),
             ("missing_uom", uom, R), ("missing_quantity", qty, S)]
    for category, before, product in cases:
        new = category == "missing_quantity"
        quantity = 3 if new else 2
        item = manual_input(before["lines"][0] if before["lines"] else {"requested_qty": quantity},
                            product, qty=quantity, new=new)
        request = dict(expected_version=1, lines=[item], deleted_line_ids=[], resolutions=[])
        after = after_manual(before, product, qty=quantity, new=new)
        bad = copy.deepcopy(request)
        kind = "APPROVE_WITH_UNRESOLVED_ISSUE"
        if category == "unknown":
            bad["lines"][0]["sku_id"] = "SAMPLE_NONEXISTENT_SKU"
            kind = "FABRICATED_SKU_REJECT"
        elif category == "multiple_variants":
            bad["expected_version"] = 0
            kind = "INVALID_VERSION_REJECT"
        elif category == "missing_uom":
            bad["lines"][0]["uom"] = "box"
            kind = "INCOMPATIBLE_UNIT_REJECT"
        else:
            bad["lines"][0]["confirmed_qty"] = None
            kind = "MANUAL_ROW_WITHOUT_QUANTITY_REJECT"
        expected_errors = {
            "unknown": (422, "REQUEST_VALIDATION_FAILED"),
            "multiple_variants": (422, "REQUEST_VALIDATION_FAILED"),
            "missing_uom": (422, "REQUEST_VALIDATION_FAILED"),
            "missing_quantity": (422, "INVALID_QUANTITY"),
        }
        http_status, error_code = expected_errors[category]
        samples.extend([
            envelope(category, "blocked", before),
            envelope(category, "after_manual", after, request=request,
                     notes="Illustrative saved version 2; no save/approval call was made."),
            envelope(category, "negative", copy.deepcopy(before), negative=negative_action(
                kind, bad, http_status, error_code, "REJECT_AND_KEEP_CURRENT_DRAFT"))])

    m = "2 bag sugar"
    missing = copy.deepcopy(B)
    missing["tier_unit_price"] = None  # diagnostic identity summary, NOT SkuCandidate
    pricing_issue = issue(m, m, "LOW_CONFIDENCE_MATCH", "NO_CANDIDATE", ask="CLERK",
        data_used={"r08": {"problem_kind": "MISSING_TIER_PRICE",
            "explanation": "Identity is ambiguous and a compatible SKU has no customer tier price. Confirm the SKU; an authorized operator must configure the missing tier price before saving.",
            "identity_candidates": [A, missing], "identity_candidates_complete": True,
            "priced_candidate_list_withheld": True, "selectable": False,
            "recovery": "CONFIRM_SKU_THEN_AUTHORIZED_PRICE_CONFIGURATION",
            "clerk_entry": {"action": "EDIT_DRAFT", "control": "CHOOSE_FROM_PRODUCT_DIRECTORY",
                            "confirmation": "SELECT_SKU_AND_SAVE", "can_configure_tier_price": False},
            "price_configuration": {"required": True, "semantic_reviewer": "Zhou",
                                    "technical_coordinator": "He", "executor": "AUTHORIZED_DATA_OPERATOR",
                                    "environment": "AUTHORIZED_CANDIDATE_ONLY",
                                    "execution_status": "NOT_RUN"}}})
    before = draft("missing_price", m, [line(m, m)], [pricing_issue])
    # Manual confirmation alone does NOT fix missing customer-tier configuration.
    after = copy.deepcopy(before)
    after["version"] = 1
    attempted = dict(expected_version=1, lines=[manual_input(before["lines"][0], B)],
                     deleted_line_ids=[], resolutions=[])
    spoof = copy.deepcopy(attempted)
    spoof["lines"][0]["unit_price_override"] = "13.20"
    spoof["lines"][0]["override_reason"] = "Must not replace a missing tier-price record"
    samples.extend([
        envelope("missing_price", "blocked", before),
        envelope("missing_price", "after_manual", after, request=attempted,
            notes="Confirmation exists only in the proposed save_request. Expected rejection 422/MISSING_TIER_PRICE; stored draft and version remain unchanged. Configuration recovery is a separate authorized R09 operation, NOT_RUN."),
        envelope("missing_price", "negative", copy.deepcopy(before), negative=negative_action(
            "OVERRIDE_CANNOT_FILL_MISSING_TIER_PRICE", spoof, 422, "MISSING_TIER_PRICE",
            "REJECT_MISSING_TIER_PRICE_OVERRIDE_DOES_NOT_REPAIR_CONFIGURATION"))])

    m = "🙂 2 bag Gula 1kg\n2 bag Garam 1kg\nkalau RM8.40 boleh?"
    lines = [line(m, "2 bag Gula 1kg", selected=A, pack="1kg"),
             line(m, "2 bag Garam 1kg", "GARAM", selected=S, pack="1kg", line_id="SAMPLE_L02")]
    cond = issue(m, "kalau RM8.40 boleh?", "CUSTOMER_CONDITION", line_id=None,
                 condition_kind="PRICE", condition_scope="UNKNOWN",
                 price_basis="UNKNOWN", requested_unit_price=None,
                 candidate_line_ids=[l["line_id"] for l in lines],
                 data_used={"requested_amount": "8.40"})
    before = draft("condition", m, lines, [cond])
    req = dict(expected_version=1, lines=[manual_input(l, p) for l, p in zip(lines, [A, S])],
               deleted_line_ids=[], resolutions=[dict(issue_id="SAMPLE_I01", choice="ACCEPT_REQUESTED_PRICE",
                 target_line_ids=["SAMPLE_L01"], confirmed_unit_price="8.40", price_basis="UNIT",
                 note="Synthetic customer confirmation: unit price 8.40 applies to the selected Gula line only.")])
    req["lines"][0].update(unit_price_override="8.40", override_reason=req["resolutions"][0]["note"])
    after = copy.deepcopy(before)
    after["version"] = 2
    after["lines"][0].update(confirmed_qty=2, match_source="MANUAL_SELECTED",
        unit_price_override="8.40", override_reason=req["resolutions"][0]["note"],
        effective_unit_price="8.40", subtotal_rm="16.80")
    after["lines"][1].update(confirmed_qty=2, match_source="MANUAL_SELECTED")
    after["issues"][0].update(resolved=True, target_line_ids=["SAMPLE_L01"],
        price_basis="UNIT", resolution="ACCEPT_REQUESTED_PRICE", resolution_note=req["resolutions"][0]["note"])
    after["issues"][0]["data_used"]["confirmed_unit_price"] = "8.40"
    after["conditions"] = copy.deepcopy(after["issues"])
    after.update(status="READY_FOR_APPROVAL", blocking_issues=[], blocked_actions={},
                 allowed_actions=["EDIT_DRAFT", "APPROVE_AND_GENERATE_DO", "CANCEL_DRAFT", "VIEW_ACTIVITY"],
                 totals=dict(order_total="26.00", currency="MYR", is_complete=True))
    bad = copy.deepcopy(req)
    bad["resolutions"][0]["target_line_ids"] = []
    samples.extend([
        envelope("condition_target", "blocked", before),
        envelope("condition_target", "after_manual", after, request=req),
        envelope("condition_target", "negative", copy.deepcopy(before), negative=negative_action(
            "ACCEPT_PRICE_WITHOUT_TARGET", bad, 400, "TARGET_LINE_REQUIRED",
            "REJECT_PRICE_ACCEPTANCE_WITHOUT_TARGET_AND_KEEP_CURRENT_DRAFT"))])

    for sample in samples:
        write("samples/" + sample["sample_id"] + ".json", sample)
    write("SAMPLE_INDEX.json", dict(contract_version="R08-CONTRACT-v0.1r1", classification="INTERFACE_SAMPLE", execution_mode="NOT_LIVE",
                                   count=len(samples), samples=[s["sample_id"] for s in samples]))
    # TS checks the original wire contract, independent of backend Pydantic.
    ts = 'import type { components } from "./reference/frontend/gate0.generated";\n'
    ts += 'type S = components["schemas"];\n'
    ts += 'export const drafts = ' + json.dumps([s["draft"] for s in samples], ensure_ascii=False, indent=2)
    ts += ' satisfies S["OrderDraft"][];\n'
    requests = [s["save_request"] for s in samples if s["save_request"]]
    ts += 'export const saves = ' + json.dumps(requests, ensure_ascii=False, indent=2)
    ts += ' satisfies S["SaveLinesRequest"][];\n'
    (ROOT / "samples.typecheck.ts").write_text(ts, "utf-8")
    print(json.dumps({"samples_built": len(samples), "live_requests": 0}))


if __name__ == "__main__":
    main()
