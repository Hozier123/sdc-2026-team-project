# R08 v0.1r1 修订回复稿

三个人均附 R08_CONTRACT_v0.1r1_REVIEW_20261101.zip，完整 SHA-256 见旁置 .sha256。以下均未代发。

**给 Ye：**

Ye，你的消费审核原件完整哈希 a21b4aa74c7386053bb2e4ea7400be54ee0d541e6a7efb64feaaa5155397bea2 已实核一致，CONSUMABLE_WITH_MODIFICATIONS 已登记。附 v0.1r1：条件 ID 已改为 CND_6BAFF2E046E11A9F84B97079，新 Issue 只用 span，4f95dd8 提交版与未提交 worktree 口径已分清。另按 Zhou 要求将缺价 ask 改 CLERK，通过现有 EDIT_DRAFT／Choose from product directory 选 SKU，诊断摘要仍不可点选；保存缺价仍拒绝且存储 draft／version 不变。你的 R10 五项待办保留为未实现，NO_CANDIDATE 仅兼容占位，必须按 MISSING_TIER_PRICE／explanation 分流。请只核这些修订及 clerk 入口是否闭合，无需重做整轮审核。新 ZIP 全 ASCII 路径，原包保留，无 live 联调结论。

**给 Xiong：**

Xiong，你对 v0.1 第 1–2 节边界可接收的回执已登记。唯一异议已按原意改为“R07 TESTED_OFFLINE + one live preflight observed (v2 evidence; P-2 not signed)”，03:28 preflight 按你转交说明登记；我没有取得并独立核验 v2 原证据，也没有新调用模型。原 R07-FIELD-v0.1 附件保留原字节，历史无 live 文字由新状态登记补充，不签 R07 验收、P-2 或语义 PASS。附 v0.1r1 新包供同步，接口边界及原保留项不变；其他修改为 Ye／Zhou 指定的样例和恢复入口补件。

**给 Zhou：**

Zhou，已登记 v0.1 合同语义 PASS、样例 PASS_WITH_CONDITIONS，以及你未独立复跑 tsc 的限制。附 v0.1r1：三项 P3 已补——missing_price_after_manual 的 save_expectation 明确 422/MISSING_TIER_PRICE、actual_result=NOT_RUN、draft_version_after=1，stored draft 与 blocked 完全相同；NO_CANDIDATE 只作兼容占位，R10 必须消费 MISSING_TIER_PRICE／explanation，不能消费则转专用码另评；ask 改 CLERK，现有目录入口确认 SKU，Zhou 核价格含义，He 核环境权限并协调有权数据执行人配置候选等级价，clerk 不获配置权限，当前未配置。负例 expected 已统一成 HTTP／错误码／行为对象，另修 Ye 的条件 ID 和 deprecated 字段。请核补件是否闭合，不重做原整轮审核；R10 仍待实现、runtime 仍 NOT_RUN，无 E 项或 R11 新结论。
