# R08 v0.1r1 审核修订包

状态：REVISED_REVIEW_DRAFT / DELTA_CLOSURE_PENDING。原 v0.1 已收到三方审核；本包落实指定修订，待核修改项闭合，尚未冻结或结项。R10 缺价展示仍未实现。

先看 CONTRACT_v0.1r1_REVIEW.md、REVIEW_CHANGELOG.md，再看 REVIEW_REPLIES.md。三个人可收同一份修订 ZIP；只核新增／修正项，不要求重做已完成的整轮审核。

## 已有结论与修订

- Ye：CONSUMABLE_WITH_MODIFICATIONS；原件哈希已核。condition_id 已按 gate0 确定性规则生成，新 Issue 不输出 deprecated source_span，保留 R10 五项待办及 worktree 未提交口径。
- Xiong：接口边界可接收；唯一状态更正已落实为 R07 TESTED_OFFLINE + one live preflight observed (v2 evidence; P-2 not signed)。只按用户转交说明登记，未取得并独立复核 preflight v2 原证据。
- Zhou：合同语义 PASS、样例 PASS_WITH_CONDITIONS。已加 save_expectation，明确缺价语义分流是 R10 必需配套，ask 改 CLERK 并写清目录入口／授权配置分工；负例统一为 HTTP／错误码／行为对象。

## 文件

- CONTRACT_v0.1r1_REVIEW.md：完整修订稿。
- REVIEW_CHANGELOG.md：逐项修订记录及保留范围。
- REVIEW_REPLIES.md：分别给三人的待转发回复稿。
- received/YE_CONSUMPTION_REVIEW_20261101.md：Ye 原件，字节哈希不变；原始文件名在登记中保留。
- received/REVIEW_RECEIPTS_UPDATE.md：Xiong、Zhou 用户转交审核及历史与当前状态区别。
- received/R07_FIELD_CONTRACT_2026-11-01.md：历史 v0.1 原件，不改早期无 live 表述，以新状态登记补充。
- received/FORWARDED_RECEIPTS_v0.1.md：编制 v0.1 时的历史登记；后续结论以 REVIEW_RECEIPTS_UPDATE.md 为准，不把历史待审状态当当前状态。
- samples/：18 个 INTERFACE_SAMPLE / NOT_LIVE 工件，新增 contract_version。
- reference/：原固定版本只读源码快照，未改应用／gate0。
- VALIDATION.json、FRONTEND_TYPECHECK.json：本修订离线检查。
- CURRENT_STATUS.json、SOURCE_PROVENANCE.json：当前分阶段状态与来源。

所有客户、SKU、价格、库存、样例 wire 时间和 ai_mode 都是人工示意，不是实际模式或 R05 答案。actual_result=NOT_RUN、actual_http_status=null；没有真实 API／数据库／模型调用、DO 或库存前后证据，不签 E01–E09／R11。

## 离线重现

需 Python 3 + Pydantic 2、TypeScript。按顺序运行 py -3 build_samples.py 和 py -3 verify_samples.py；再用已有 tsc 对 samples.typecheck.ts 执行 --noEmit --skipLibCheck --strict --target ES2022 --moduleResolution bundler --module ESNext。

新归档路径均为 ASCII；文档内容 UTF-8。原包保留，新包独立哈希；重生成导致字节变化时应重新出版本／清单，不能覆盖已发送归档。
