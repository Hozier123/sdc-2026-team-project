"""Validate review artifacts, not runtime/API behavior. No network or DB calls."""
from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("r08_reference_schemas", ROOT / "reference/backend/schemas.py")
schemas = importlib.util.module_from_spec(spec)
spec.loader.exec_module(schemas)
for cls in [v for v in vars(schemas).values() if isinstance(v, type) and issubclass(v, schemas.BaseModel)]:
    if cls.__module__ == schemas.__name__:
        cls.model_rebuild(_types_namespace=vars(schemas))


def invariant(draft):
    schemas.OrderDraftResponse.model_validate(draft)
    active = sorted({i["code"] for i in draft["issues"] if i["blocking"] and not i["resolved"]})
    assert active == draft["blocking_issues"], "blocking subset mismatch"
    assert draft["conditions"] == [i for i in draft["issues"] if i["code"] == "CUSTOMER_CONDITION"]
    if active:
        assert draft["status"] == "DISAMBIGUATION_REQUIRED"
        for action in ["APPROVE_AND_GENERATE_DO", "SUBMIT_FOR_OWNER", "OWNER_APPROVE"]:
            assert action not in draft["allowed_actions"], "unresolved issue permits approval"
            assert draft["blocked_actions"].get(action), "missing blocked-action reason"
    assert draft["do_number"] is None
    ids = {l["line_id"] for l in draft["lines"]}
    assert len(ids) == len(draft["lines"])
    message = draft["masked_message"]
    for l in draft["lines"]:
        assert l["family_id"] in {"UNKNOWN", "FAM_GULA", "FAM_BERAS", "FAM_GARAM"}
        assert message[l["span_start"]:l["span_end"]] == l["source_span"]
        for e in l["field_evidence"]:
            assert e["field"] in {"qty", "uom", "pack_size"}, "invented family evidence"
            assert e["end"] > e["start"] >= 0
            assert message[e["start"]:e["end"]] == e["raw_text"]
        for c in l["candidate_skus"]:
            assert c["family_id"] == l["family_id"]
            assert c["tier_unit_price"] is not None
        if l["effective_unit_price"] is not None:
            assert Decimal(l["subtotal_rm"]) == Decimal(l["effective_unit_price"]) * l["effective_qty"]
    for i in draft["issues"]:
        assert "source_span" not in i, "new Issue examples must use span rather than deprecated source_span"
        assert not i.get("line_id") or i["line_id"] in ids
        assert set(i["candidate_line_ids"]) <= ids
        assert set(i["target_line_ids"]) <= ids
        assert message[i["span_start"]:i["span_end"]] == i["span"]
        if i["code"] == "CUSTOMER_CONDITION":
            material = f"{draft['draft_id']}|{i['condition_kind']}|{i['span_start']}|{i['span_end']}"
            assert i["condition_id"] == "CND_" + hashlib.sha256(material.encode("utf-8")).hexdigest()[:24].upper()
    if draft["totals"]["is_complete"]:
        assert Decimal(draft["totals"]["order_total"]) == sum(Decimal(l["subtotal_rm"]) for l in draft["lines"])


def must_reject(fn, label):
    try:
        fn()
    except (AssertionError, ValueError):
        return dict(check=label, result="EXPECTED_REJECTION_OBSERVED_OFFLINE")
    raise AssertionError("negative artifact accepted: " + label)


def transition(s):
    e, request, response = s["save_expectation"], s["save_request"], s["draft"]
    assert e["actual_result"] == "NOT_RUN" and e["actual_http_status"] is None
    assert e["draft_version_before"] == request["expected_version"]
    assert e["draft_version_after"] == response["version"]
    if e["http_status"] >= 400:
        assert e["stored_draft_behavior"] == "UNCHANGED"
        assert response["version"] == request["expected_version"]
    else:
        assert response["version"] == request["expected_version"] + 1


def price_route(d):
    i = d["issues"][0]
    r = i["data_used"].get("r08", {})
    assert i["reason_code"] == "NO_CANDIDATE"
    assert r.get("problem_kind") == "MISSING_TIER_PRICE", "missing semantic discriminator"
    assert r.get("explanation"), "missing explicit missing-price explanation"
    assert r.get("selectable") is False
    assert i["ask"] == "CLERK"
    assert r["clerk_entry"]["action"] in d["allowed_actions"]
    assert r["clerk_entry"]["can_configure_tier_price"] is False
    assert r["price_configuration"]["execution_status"] == "NOT_RUN"


def main():
    rows = []
    samples = {}
    for p in sorted((ROOT / "samples").glob("*.json")):
        s = json.loads(p.read_text("utf-8"))
        assert s["classification"] == "INTERFACE_SAMPLE" and s["execution_mode"] == "NOT_LIVE"
        assert s["contract_version"] == "R08-CONTRACT-v0.1r1"
        assert s["runtime_execution_status"] == "NOT_RUN"
        assert s["side_effects"]["actual_inventory_before"] is None
        assert s["approval_expectation"]["actual_http_status"] is None
        invariant(s["draft"])
        if s["save_request"]:
            schemas.SaveLinesRequest.model_validate(s["save_request"])
            transition(s)
        if s["sample_id"].startswith("missing_price_"):
            price_route(s["draft"])
        if s["negative_example"]:
            n = s["negative_example"]
            assert n["actual_result"] == "NOT_RUN" and n["actual_http_status"] is None
            assert n["expected"]["http_status"] >= 400
            assert n["expected"]["error_code"] and n["expected"]["behavior"]
        rows.append(dict(sample_id=s["sample_id"], backend_schema="PASS", artifact_invariants="PASS",
                         runtime_behavior="NOT_RUN", independent_acceptance="PENDING"))
        samples[s["sample_id"]] = s
    assert len(samples) == 18
    for category in ["unknown", "multiple_variants", "missing_uom", "missing_quantity", "missing_price", "condition_target"]:
        assert all(category + "_" + phase in samples for phase in ["blocked", "after_manual", "negative"])
    assert not samples["missing_quantity_blocked"]["draft"]["lines"]
    assert samples["missing_quantity_after_manual"]["draft"]["lines"][0]["match_source"] == "MANUAL_SELECTED"
    assert {c["sku_id"] for c in samples["multiple_variants_blocked"]["draft"]["lines"][0]["candidate_skus"]} == {"SAMPLE_GULA_1KG", "SAMPLE_GULA_2KG"}
    price = samples["missing_price_blocked"]["draft"]
    assert not price["lines"][0]["candidate_skus"] and price["lines"][0]["sku_id"] is None
    summary = price["issues"][0]["data_used"]["r08"]["identity_candidates"]
    assert len(summary) == 2 and any(c["tier_unit_price"] is None for c in summary)
    assert samples["missing_price_after_manual"]["draft"]["version"] == 1
    assert samples["missing_price_after_manual"]["draft"]["blocking_issues"]
    assert samples["missing_price_after_manual"]["draft"] == price, "rejected save must preserve stored state"
    assert samples["missing_price_after_manual"]["save_expectation"] == {
        "http_status": 422, "error_code": "MISSING_TIER_PRICE", "actual_result": "NOT_RUN",
        "actual_http_status": None, "draft_version_before": 1, "draft_version_after": 1,
        "stored_draft_behavior": "UNCHANGED"}
    assert price["issues"][0]["ask"] == "CLERK"
    assert price["issues"][0]["data_used"]["r08"]["clerk_entry"]["action"] in price["allowed_actions"]
    assert price["issues"][0]["data_used"]["r08"]["price_configuration"]["execution_status"] == "NOT_RUN"
    results = []
    bad = copy.deepcopy(price)
    bad["allowed_actions"].append("APPROVE_AND_GENERATE_DO")
    results.append(must_reject(lambda: invariant(bad), "contradictory approval flags"))
    bad_candidate = copy.deepcopy(summary[1])
    results.append(must_reject(lambda: schemas.SkuCandidate.model_validate(bad_candidate), "null priced SkuCandidate"))
    bad = copy.deepcopy(samples["condition_target_blocked"]["draft"])
    bad["lines"][0]["field_evidence"][0]["start"] += 1
    results.append(must_reject(lambda: invariant(bad), "emoji code-point evidence offset corruption"))
    bad = copy.deepcopy(samples["multiple_variants_negative"]["negative_example"]["request"])
    results.append(must_reject(lambda: schemas.SaveLinesRequest.model_validate(bad), "zero expected_version"))
    bad = copy.deepcopy(samples["condition_target_blocked"]["draft"])
    bad["issues"][0]["condition_id"] = "SAMPLE_C01"
    bad["conditions"][0]["condition_id"] = "SAMPLE_C01"
    results.append(must_reject(lambda: invariant(bad), "placeholder condition_id"))
    bad = copy.deepcopy(samples["missing_price_after_manual"])
    bad["save_expectation"]["draft_version_after"] = 2
    results.append(must_reject(lambda: transition(bad), "version advance after rejected save"))
    bad = copy.deepcopy(price)
    bad["issues"][0]["data_used"]["r08"].pop("problem_kind")
    results.append(must_reject(lambda: price_route(bad), "generic NO_CANDIDATE without missing-price routing"))
    # Source provenance verifies the upstream document example separately.
    source = (ROOT / "received/R07_FIELD_CONTRACT_2026-11-01.md").read_text("utf-8")
    raw = json.loads(source.split("```json\n", 1)[1].split("```", 1)[0])
    message = "2 bag 食盐 1kg\n2 bag Gula 2kg, kalau RM90 boleh?"
    for r in raw["rows"]:
        for e in r["field_evidence"]:
            assert message[e["start"]:e["end"]] == e["raw_text"]
    for c in raw["conditions"]:
        assert message[c["start"]:c["end"]] == c["span"]
    report = dict(checked_at_utc=datetime.now(timezone.utc).isoformat(),
                  status="OFFLINE_ARTIFACT_CHECKS_PASSED", samples=rows,
                  negative_artifact_checks=results, r07_document_example_coordinates="PASS",
                  frontend_typecheck="SEE_FRONTEND_TYPECHECK_LOG", api_requests=0,
                  database_connections=0, model_requests=0,
                  actual_approval_rejection="NOT_RUN", actual_inventory_before_after="NOT_RUN",
                  R08_review="PRIOR_CONDITIONAL_REVIEWS_RECORDED_DELTA_CLOSURE_PENDING",
                  R05_R11_E01_E09="NO_CLAIM")
    (ROOT / "VALIDATION.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", "utf-8")
    print(json.dumps({"samples": len(rows), "negative_artifact_checks": len(results),
                      "status": report["status"], "runtime_tests": "NOT_RUN"}))


if __name__ == "__main__":
    main()
