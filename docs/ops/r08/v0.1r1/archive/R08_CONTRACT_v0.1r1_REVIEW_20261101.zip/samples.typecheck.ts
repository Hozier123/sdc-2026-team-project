import type { components } from "./reference/frontend/gate0.generated";
type S = components["schemas"];
export const drafts = [
  {
    "draft_id": "SAMPLE_R08_UNKNOWN",
    "version": 1,
    "status": "DISAMBIGUATION_REQUIRED",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "2 bag gula misteri",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": null,
        "family_id": "UNKNOWN",
        "description": "2 bag gula misteri",
        "requested_qty": 2,
        "confirmed_qty": null,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": null,
        "grade": null,
        "tier_unit_price": null,
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": null,
        "subtotal_rm": null,
        "match_source": "RAPIDFUZZ_FALLBACK",
        "source_span": "2 bag gula misteri",
        "span_start": 0,
        "span_end": 18,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 0,
            "end": 1,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 2,
            "end": 5,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": null
      }
    ],
    "issues": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "LOW_CONFIDENCE_MATCH",
        "line_id": "SAMPLE_L01",
        "span": "2 bag gula misteri",
        "span_start": 0,
        "span_end": 18,
        "candidate_line_ids": [],
        "target_line_ids": [],
        "reason_code": "UNKNOWN_PRODUCT",
        "ask": "CLERK",
        "data_used": {},
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null
      }
    ],
    "conditions": [],
    "blocking_issues": [
      "LOW_CONFIDENCE_MATCH"
    ],
    "escalation_preview": [],
    "totals": {
      "order_total": null,
      "currency": "MYR",
      "is_complete": false
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "RESOLVE_ISSUE",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {
      "APPROVE_AND_GENERATE_DO": [
        "LOW_CONFIDENCE_MATCH"
      ],
      "SUBMIT_FOR_OWNER": [
        "LOW_CONFIDENCE_MATCH"
      ],
      "OWNER_APPROVE": [
        "LOW_CONFIDENCE_MATCH"
      ]
    },
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_UNKNOWN",
    "version": 2,
    "status": "READY_FOR_APPROVAL",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "2 bag gula misteri",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": "SAMPLE_GULA_1KG",
        "family_id": "FAM_GULA",
        "description": "Interface sample GULA_1KG",
        "requested_qty": 2,
        "confirmed_qty": 2,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": "1kg",
        "grade": null,
        "tier_unit_price": "7.10",
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": "7.10",
        "subtotal_rm": "14.20",
        "match_source": "MANUAL_SELECTED",
        "source_span": "2 bag gula misteri",
        "span_start": 0,
        "span_end": 18,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 0,
            "end": 1,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 2,
            "end": 5,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": 30
      }
    ],
    "issues": [],
    "conditions": [],
    "blocking_issues": [],
    "escalation_preview": [],
    "totals": {
      "order_total": "14.20",
      "currency": "MYR",
      "is_complete": true
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "APPROVE_AND_GENERATE_DO",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {},
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_UNKNOWN",
    "version": 1,
    "status": "DISAMBIGUATION_REQUIRED",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "2 bag gula misteri",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": null,
        "family_id": "UNKNOWN",
        "description": "2 bag gula misteri",
        "requested_qty": 2,
        "confirmed_qty": null,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": null,
        "grade": null,
        "tier_unit_price": null,
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": null,
        "subtotal_rm": null,
        "match_source": "RAPIDFUZZ_FALLBACK",
        "source_span": "2 bag gula misteri",
        "span_start": 0,
        "span_end": 18,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 0,
            "end": 1,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 2,
            "end": 5,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": null
      }
    ],
    "issues": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "LOW_CONFIDENCE_MATCH",
        "line_id": "SAMPLE_L01",
        "span": "2 bag gula misteri",
        "span_start": 0,
        "span_end": 18,
        "candidate_line_ids": [],
        "target_line_ids": [],
        "reason_code": "UNKNOWN_PRODUCT",
        "ask": "CLERK",
        "data_used": {},
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null
      }
    ],
    "conditions": [],
    "blocking_issues": [
      "LOW_CONFIDENCE_MATCH"
    ],
    "escalation_preview": [],
    "totals": {
      "order_total": null,
      "currency": "MYR",
      "is_complete": false
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "RESOLVE_ISSUE",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {
      "APPROVE_AND_GENERATE_DO": [
        "LOW_CONFIDENCE_MATCH"
      ],
      "SUBMIT_FOR_OWNER": [
        "LOW_CONFIDENCE_MATCH"
      ],
      "OWNER_APPROVE": [
        "LOW_CONFIDENCE_MATCH"
      ]
    },
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_AMBIGUOUS",
    "version": 1,
    "status": "DISAMBIGUATION_REQUIRED",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "2 bag sugar",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": null,
        "family_id": "FAM_GULA",
        "description": "2 bag sugar",
        "requested_qty": 2,
        "confirmed_qty": null,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": null,
        "grade": null,
        "tier_unit_price": null,
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": null,
        "subtotal_rm": null,
        "match_source": "RAPIDFUZZ_FALLBACK",
        "source_span": "2 bag sugar",
        "span_start": 0,
        "span_end": 11,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 0,
            "end": 1,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 2,
            "end": 5,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [
          {
            "sku_id": "SAMPLE_GULA_1KG",
            "family_id": "FAM_GULA",
            "display_name": "Interface sample GULA_1KG",
            "pack_size": "1kg",
            "grade": null,
            "base_unit": "bag",
            "tier_unit_price": "7.10",
            "available_qty": 30
          },
          {
            "sku_id": "SAMPLE_GULA_2KG",
            "family_id": "FAM_GULA",
            "display_name": "Interface sample GULA_2KG",
            "pack_size": "2kg",
            "grade": null,
            "base_unit": "bag",
            "tier_unit_price": "13.20",
            "available_qty": 30
          }
        ],
        "saved_alias": null,
        "available_qty": null
      }
    ],
    "issues": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "MULTIPLE_PACK_SIZES",
        "line_id": "SAMPLE_L01",
        "span": "2 bag sugar",
        "span_start": 0,
        "span_end": 11,
        "candidate_line_ids": [],
        "target_line_ids": [],
        "reason_code": null,
        "ask": "CLERK",
        "data_used": {},
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null
      }
    ],
    "conditions": [],
    "blocking_issues": [
      "MULTIPLE_PACK_SIZES"
    ],
    "escalation_preview": [],
    "totals": {
      "order_total": null,
      "currency": "MYR",
      "is_complete": false
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "RESOLVE_ISSUE",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {
      "APPROVE_AND_GENERATE_DO": [
        "MULTIPLE_PACK_SIZES"
      ],
      "SUBMIT_FOR_OWNER": [
        "MULTIPLE_PACK_SIZES"
      ],
      "OWNER_APPROVE": [
        "MULTIPLE_PACK_SIZES"
      ]
    },
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_AMBIGUOUS",
    "version": 2,
    "status": "READY_FOR_APPROVAL",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "2 bag sugar",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": "SAMPLE_GULA_2KG",
        "family_id": "FAM_GULA",
        "description": "Interface sample GULA_2KG",
        "requested_qty": 2,
        "confirmed_qty": 2,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": "2kg",
        "grade": null,
        "tier_unit_price": "13.20",
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": "13.20",
        "subtotal_rm": "26.40",
        "match_source": "MANUAL_SELECTED",
        "source_span": "2 bag sugar",
        "span_start": 0,
        "span_end": 11,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 0,
            "end": 1,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 2,
            "end": 5,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": 30
      }
    ],
    "issues": [],
    "conditions": [],
    "blocking_issues": [],
    "escalation_preview": [],
    "totals": {
      "order_total": "26.40",
      "currency": "MYR",
      "is_complete": true
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "APPROVE_AND_GENERATE_DO",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {},
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_AMBIGUOUS",
    "version": 1,
    "status": "DISAMBIGUATION_REQUIRED",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "2 bag sugar",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": null,
        "family_id": "FAM_GULA",
        "description": "2 bag sugar",
        "requested_qty": 2,
        "confirmed_qty": null,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": null,
        "grade": null,
        "tier_unit_price": null,
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": null,
        "subtotal_rm": null,
        "match_source": "RAPIDFUZZ_FALLBACK",
        "source_span": "2 bag sugar",
        "span_start": 0,
        "span_end": 11,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 0,
            "end": 1,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 2,
            "end": 5,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [
          {
            "sku_id": "SAMPLE_GULA_1KG",
            "family_id": "FAM_GULA",
            "display_name": "Interface sample GULA_1KG",
            "pack_size": "1kg",
            "grade": null,
            "base_unit": "bag",
            "tier_unit_price": "7.10",
            "available_qty": 30
          },
          {
            "sku_id": "SAMPLE_GULA_2KG",
            "family_id": "FAM_GULA",
            "display_name": "Interface sample GULA_2KG",
            "pack_size": "2kg",
            "grade": null,
            "base_unit": "bag",
            "tier_unit_price": "13.20",
            "available_qty": 30
          }
        ],
        "saved_alias": null,
        "available_qty": null
      }
    ],
    "issues": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "MULTIPLE_PACK_SIZES",
        "line_id": "SAMPLE_L01",
        "span": "2 bag sugar",
        "span_start": 0,
        "span_end": 11,
        "candidate_line_ids": [],
        "target_line_ids": [],
        "reason_code": null,
        "ask": "CLERK",
        "data_used": {},
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null
      }
    ],
    "conditions": [],
    "blocking_issues": [
      "MULTIPLE_PACK_SIZES"
    ],
    "escalation_preview": [],
    "totals": {
      "order_total": null,
      "currency": "MYR",
      "is_complete": false
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "RESOLVE_ISSUE",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {
      "APPROVE_AND_GENERATE_DO": [
        "MULTIPLE_PACK_SIZES"
      ],
      "SUBMIT_FOR_OWNER": [
        "MULTIPLE_PACK_SIZES"
      ],
      "OWNER_APPROVE": [
        "MULTIPLE_PACK_SIZES"
      ]
    },
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_MISSING_UOM",
    "version": 1,
    "status": "DISAMBIGUATION_REQUIRED",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "2 Beras 5kg",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": null,
        "family_id": "FAM_BERAS",
        "description": "2 Beras 5kg",
        "requested_qty": 2,
        "confirmed_qty": null,
        "effective_qty": 2,
        "uom": null,
        "pack_size": "5kg",
        "grade": null,
        "tier_unit_price": null,
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": null,
        "subtotal_rm": null,
        "match_source": "RAPIDFUZZ_FALLBACK",
        "source_span": "2 Beras 5kg",
        "span_start": 0,
        "span_end": 11,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 0,
            "end": 1,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "pack_size",
            "raw_text": "5kg",
            "start": 8,
            "end": 11,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [
          {
            "sku_id": "SAMPLE_BERAS_5KG",
            "family_id": "FAM_BERAS",
            "display_name": "Interface sample BERAS_5KG",
            "pack_size": "5kg",
            "grade": null,
            "base_unit": "bag",
            "tier_unit_price": "21.30",
            "available_qty": 30
          }
        ],
        "saved_alias": null,
        "available_qty": null
      }
    ],
    "issues": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "MISSING_UOM",
        "line_id": "SAMPLE_L01",
        "span": "2 Beras 5kg",
        "span_start": 0,
        "span_end": 11,
        "candidate_line_ids": [],
        "target_line_ids": [],
        "reason_code": "FIELD_NOT_EVIDENCED",
        "ask": "CLERK",
        "data_used": {},
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null
      }
    ],
    "conditions": [],
    "blocking_issues": [
      "MISSING_UOM"
    ],
    "escalation_preview": [],
    "totals": {
      "order_total": null,
      "currency": "MYR",
      "is_complete": false
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "RESOLVE_ISSUE",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {
      "APPROVE_AND_GENERATE_DO": [
        "MISSING_UOM"
      ],
      "SUBMIT_FOR_OWNER": [
        "MISSING_UOM"
      ],
      "OWNER_APPROVE": [
        "MISSING_UOM"
      ]
    },
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_MISSING_UOM",
    "version": 2,
    "status": "READY_FOR_APPROVAL",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "2 Beras 5kg",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": "SAMPLE_BERAS_5KG",
        "family_id": "FAM_BERAS",
        "description": "Interface sample BERAS_5KG",
        "requested_qty": 2,
        "confirmed_qty": 2,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": "5kg",
        "grade": null,
        "tier_unit_price": "21.30",
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": "21.30",
        "subtotal_rm": "42.60",
        "match_source": "MANUAL_SELECTED",
        "source_span": "2 Beras 5kg",
        "span_start": 0,
        "span_end": 11,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 0,
            "end": 1,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "pack_size",
            "raw_text": "5kg",
            "start": 8,
            "end": 11,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": 30
      }
    ],
    "issues": [],
    "conditions": [],
    "blocking_issues": [],
    "escalation_preview": [],
    "totals": {
      "order_total": "42.60",
      "currency": "MYR",
      "is_complete": true
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "APPROVE_AND_GENERATE_DO",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {},
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_MISSING_UOM",
    "version": 1,
    "status": "DISAMBIGUATION_REQUIRED",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "2 Beras 5kg",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": null,
        "family_id": "FAM_BERAS",
        "description": "2 Beras 5kg",
        "requested_qty": 2,
        "confirmed_qty": null,
        "effective_qty": 2,
        "uom": null,
        "pack_size": "5kg",
        "grade": null,
        "tier_unit_price": null,
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": null,
        "subtotal_rm": null,
        "match_source": "RAPIDFUZZ_FALLBACK",
        "source_span": "2 Beras 5kg",
        "span_start": 0,
        "span_end": 11,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 0,
            "end": 1,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "pack_size",
            "raw_text": "5kg",
            "start": 8,
            "end": 11,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [
          {
            "sku_id": "SAMPLE_BERAS_5KG",
            "family_id": "FAM_BERAS",
            "display_name": "Interface sample BERAS_5KG",
            "pack_size": "5kg",
            "grade": null,
            "base_unit": "bag",
            "tier_unit_price": "21.30",
            "available_qty": 30
          }
        ],
        "saved_alias": null,
        "available_qty": null
      }
    ],
    "issues": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "MISSING_UOM",
        "line_id": "SAMPLE_L01",
        "span": "2 Beras 5kg",
        "span_start": 0,
        "span_end": 11,
        "candidate_line_ids": [],
        "target_line_ids": [],
        "reason_code": "FIELD_NOT_EVIDENCED",
        "ask": "CLERK",
        "data_used": {},
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null
      }
    ],
    "conditions": [],
    "blocking_issues": [
      "MISSING_UOM"
    ],
    "escalation_preview": [],
    "totals": {
      "order_total": null,
      "currency": "MYR",
      "is_complete": false
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "RESOLVE_ISSUE",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {
      "APPROVE_AND_GENERATE_DO": [
        "MISSING_UOM"
      ],
      "SUBMIT_FOR_OWNER": [
        "MISSING_UOM"
      ],
      "OWNER_APPROVE": [
        "MISSING_UOM"
      ]
    },
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_MISSING_QTY",
    "version": 1,
    "status": "DISAMBIGUATION_REQUIRED",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "Garam 1kg",
    "ai_mode": "FALLBACK",
    "lines": [],
    "issues": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "LOW_CONFIDENCE_MATCH",
        "line_id": null,
        "span": "Garam 1kg",
        "span_start": 0,
        "span_end": 9,
        "candidate_line_ids": [],
        "target_line_ids": [],
        "reason_code": "INVALID_QUANTITY",
        "ask": "CLERK",
        "data_used": {
          "r08": {
            "problem_kind": "MISSING_QUANTITY",
            "family_id": "FAM_GARAM",
            "requested_qty": null,
            "pack_size": "1kg",
            "recovery": "MANUAL_ADD_LINE"
          }
        },
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null
      }
    ],
    "conditions": [],
    "blocking_issues": [
      "LOW_CONFIDENCE_MATCH"
    ],
    "escalation_preview": [],
    "totals": {
      "order_total": null,
      "currency": "MYR",
      "is_complete": false
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "RESOLVE_ISSUE",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {
      "APPROVE_AND_GENERATE_DO": [
        "LOW_CONFIDENCE_MATCH"
      ],
      "SUBMIT_FOR_OWNER": [
        "LOW_CONFIDENCE_MATCH"
      ],
      "OWNER_APPROVE": [
        "LOW_CONFIDENCE_MATCH"
      ]
    },
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_MISSING_QTY",
    "version": 2,
    "status": "READY_FOR_APPROVAL",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "Garam 1kg",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": "SAMPLE_MANUAL_01",
        "sku_id": "SAMPLE_GARAM_1KG",
        "family_id": "FAM_GARAM",
        "description": "Interface sample GARAM_1KG",
        "requested_qty": 3,
        "confirmed_qty": 3,
        "effective_qty": 3,
        "uom": "bag",
        "pack_size": "1kg",
        "grade": null,
        "tier_unit_price": "4.60",
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": "4.60",
        "subtotal_rm": "13.80",
        "match_source": "MANUAL_SELECTED",
        "source_span": "Garam 1kg",
        "span_start": 0,
        "span_end": 9,
        "field_evidence": [
          {
            "field": "pack_size",
            "raw_text": "1kg",
            "start": 6,
            "end": 9,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": 30
      }
    ],
    "issues": [],
    "conditions": [],
    "blocking_issues": [],
    "escalation_preview": [],
    "totals": {
      "order_total": "13.80",
      "currency": "MYR",
      "is_complete": true
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "APPROVE_AND_GENERATE_DO",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {},
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_MISSING_QTY",
    "version": 1,
    "status": "DISAMBIGUATION_REQUIRED",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "Garam 1kg",
    "ai_mode": "FALLBACK",
    "lines": [],
    "issues": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "LOW_CONFIDENCE_MATCH",
        "line_id": null,
        "span": "Garam 1kg",
        "span_start": 0,
        "span_end": 9,
        "candidate_line_ids": [],
        "target_line_ids": [],
        "reason_code": "INVALID_QUANTITY",
        "ask": "CLERK",
        "data_used": {
          "r08": {
            "problem_kind": "MISSING_QUANTITY",
            "family_id": "FAM_GARAM",
            "requested_qty": null,
            "pack_size": "1kg",
            "recovery": "MANUAL_ADD_LINE"
          }
        },
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null
      }
    ],
    "conditions": [],
    "blocking_issues": [
      "LOW_CONFIDENCE_MATCH"
    ],
    "escalation_preview": [],
    "totals": {
      "order_total": null,
      "currency": "MYR",
      "is_complete": false
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "RESOLVE_ISSUE",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {
      "APPROVE_AND_GENERATE_DO": [
        "LOW_CONFIDENCE_MATCH"
      ],
      "SUBMIT_FOR_OWNER": [
        "LOW_CONFIDENCE_MATCH"
      ],
      "OWNER_APPROVE": [
        "LOW_CONFIDENCE_MATCH"
      ]
    },
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_MISSING_PRICE",
    "version": 1,
    "status": "DISAMBIGUATION_REQUIRED",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "2 bag sugar",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": null,
        "family_id": "FAM_GULA",
        "description": "2 bag sugar",
        "requested_qty": 2,
        "confirmed_qty": null,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": null,
        "grade": null,
        "tier_unit_price": null,
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": null,
        "subtotal_rm": null,
        "match_source": "RAPIDFUZZ_FALLBACK",
        "source_span": "2 bag sugar",
        "span_start": 0,
        "span_end": 11,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 0,
            "end": 1,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 2,
            "end": 5,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": null
      }
    ],
    "issues": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "LOW_CONFIDENCE_MATCH",
        "line_id": "SAMPLE_L01",
        "span": "2 bag sugar",
        "span_start": 0,
        "span_end": 11,
        "candidate_line_ids": [],
        "target_line_ids": [],
        "reason_code": "NO_CANDIDATE",
        "ask": "CLERK",
        "data_used": {
          "r08": {
            "problem_kind": "MISSING_TIER_PRICE",
            "explanation": "Identity is ambiguous and a compatible SKU has no customer tier price. Confirm the SKU; an authorized operator must configure the missing tier price before saving.",
            "identity_candidates": [
              {
                "sku_id": "SAMPLE_GULA_1KG",
                "family_id": "FAM_GULA",
                "display_name": "Interface sample GULA_1KG",
                "pack_size": "1kg",
                "grade": null,
                "base_unit": "bag",
                "tier_unit_price": "7.10",
                "available_qty": 30
              },
              {
                "sku_id": "SAMPLE_GULA_2KG",
                "family_id": "FAM_GULA",
                "display_name": "Interface sample GULA_2KG",
                "pack_size": "2kg",
                "grade": null,
                "base_unit": "bag",
                "tier_unit_price": null,
                "available_qty": 30
              }
            ],
            "identity_candidates_complete": true,
            "priced_candidate_list_withheld": true,
            "selectable": false,
            "recovery": "CONFIRM_SKU_THEN_AUTHORIZED_PRICE_CONFIGURATION",
            "clerk_entry": {
              "action": "EDIT_DRAFT",
              "control": "CHOOSE_FROM_PRODUCT_DIRECTORY",
              "confirmation": "SELECT_SKU_AND_SAVE",
              "can_configure_tier_price": false
            },
            "price_configuration": {
              "required": true,
              "semantic_reviewer": "Zhou",
              "technical_coordinator": "He",
              "executor": "AUTHORIZED_DATA_OPERATOR",
              "environment": "AUTHORIZED_CANDIDATE_ONLY",
              "execution_status": "NOT_RUN"
            }
          }
        },
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null
      }
    ],
    "conditions": [],
    "blocking_issues": [
      "LOW_CONFIDENCE_MATCH"
    ],
    "escalation_preview": [],
    "totals": {
      "order_total": null,
      "currency": "MYR",
      "is_complete": false
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "RESOLVE_ISSUE",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {
      "APPROVE_AND_GENERATE_DO": [
        "LOW_CONFIDENCE_MATCH"
      ],
      "SUBMIT_FOR_OWNER": [
        "LOW_CONFIDENCE_MATCH"
      ],
      "OWNER_APPROVE": [
        "LOW_CONFIDENCE_MATCH"
      ]
    },
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_MISSING_PRICE",
    "version": 1,
    "status": "DISAMBIGUATION_REQUIRED",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "2 bag sugar",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": null,
        "family_id": "FAM_GULA",
        "description": "2 bag sugar",
        "requested_qty": 2,
        "confirmed_qty": null,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": null,
        "grade": null,
        "tier_unit_price": null,
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": null,
        "subtotal_rm": null,
        "match_source": "RAPIDFUZZ_FALLBACK",
        "source_span": "2 bag sugar",
        "span_start": 0,
        "span_end": 11,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 0,
            "end": 1,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 2,
            "end": 5,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": null
      }
    ],
    "issues": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "LOW_CONFIDENCE_MATCH",
        "line_id": "SAMPLE_L01",
        "span": "2 bag sugar",
        "span_start": 0,
        "span_end": 11,
        "candidate_line_ids": [],
        "target_line_ids": [],
        "reason_code": "NO_CANDIDATE",
        "ask": "CLERK",
        "data_used": {
          "r08": {
            "problem_kind": "MISSING_TIER_PRICE",
            "explanation": "Identity is ambiguous and a compatible SKU has no customer tier price. Confirm the SKU; an authorized operator must configure the missing tier price before saving.",
            "identity_candidates": [
              {
                "sku_id": "SAMPLE_GULA_1KG",
                "family_id": "FAM_GULA",
                "display_name": "Interface sample GULA_1KG",
                "pack_size": "1kg",
                "grade": null,
                "base_unit": "bag",
                "tier_unit_price": "7.10",
                "available_qty": 30
              },
              {
                "sku_id": "SAMPLE_GULA_2KG",
                "family_id": "FAM_GULA",
                "display_name": "Interface sample GULA_2KG",
                "pack_size": "2kg",
                "grade": null,
                "base_unit": "bag",
                "tier_unit_price": null,
                "available_qty": 30
              }
            ],
            "identity_candidates_complete": true,
            "priced_candidate_list_withheld": true,
            "selectable": false,
            "recovery": "CONFIRM_SKU_THEN_AUTHORIZED_PRICE_CONFIGURATION",
            "clerk_entry": {
              "action": "EDIT_DRAFT",
              "control": "CHOOSE_FROM_PRODUCT_DIRECTORY",
              "confirmation": "SELECT_SKU_AND_SAVE",
              "can_configure_tier_price": false
            },
            "price_configuration": {
              "required": true,
              "semantic_reviewer": "Zhou",
              "technical_coordinator": "He",
              "executor": "AUTHORIZED_DATA_OPERATOR",
              "environment": "AUTHORIZED_CANDIDATE_ONLY",
              "execution_status": "NOT_RUN"
            }
          }
        },
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null
      }
    ],
    "conditions": [],
    "blocking_issues": [
      "LOW_CONFIDENCE_MATCH"
    ],
    "escalation_preview": [],
    "totals": {
      "order_total": null,
      "currency": "MYR",
      "is_complete": false
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "RESOLVE_ISSUE",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {
      "APPROVE_AND_GENERATE_DO": [
        "LOW_CONFIDENCE_MATCH"
      ],
      "SUBMIT_FOR_OWNER": [
        "LOW_CONFIDENCE_MATCH"
      ],
      "OWNER_APPROVE": [
        "LOW_CONFIDENCE_MATCH"
      ]
    },
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_MISSING_PRICE",
    "version": 1,
    "status": "DISAMBIGUATION_REQUIRED",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "2 bag sugar",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": null,
        "family_id": "FAM_GULA",
        "description": "2 bag sugar",
        "requested_qty": 2,
        "confirmed_qty": null,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": null,
        "grade": null,
        "tier_unit_price": null,
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": null,
        "subtotal_rm": null,
        "match_source": "RAPIDFUZZ_FALLBACK",
        "source_span": "2 bag sugar",
        "span_start": 0,
        "span_end": 11,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 0,
            "end": 1,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 2,
            "end": 5,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": null
      }
    ],
    "issues": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "LOW_CONFIDENCE_MATCH",
        "line_id": "SAMPLE_L01",
        "span": "2 bag sugar",
        "span_start": 0,
        "span_end": 11,
        "candidate_line_ids": [],
        "target_line_ids": [],
        "reason_code": "NO_CANDIDATE",
        "ask": "CLERK",
        "data_used": {
          "r08": {
            "problem_kind": "MISSING_TIER_PRICE",
            "explanation": "Identity is ambiguous and a compatible SKU has no customer tier price. Confirm the SKU; an authorized operator must configure the missing tier price before saving.",
            "identity_candidates": [
              {
                "sku_id": "SAMPLE_GULA_1KG",
                "family_id": "FAM_GULA",
                "display_name": "Interface sample GULA_1KG",
                "pack_size": "1kg",
                "grade": null,
                "base_unit": "bag",
                "tier_unit_price": "7.10",
                "available_qty": 30
              },
              {
                "sku_id": "SAMPLE_GULA_2KG",
                "family_id": "FAM_GULA",
                "display_name": "Interface sample GULA_2KG",
                "pack_size": "2kg",
                "grade": null,
                "base_unit": "bag",
                "tier_unit_price": null,
                "available_qty": 30
              }
            ],
            "identity_candidates_complete": true,
            "priced_candidate_list_withheld": true,
            "selectable": false,
            "recovery": "CONFIRM_SKU_THEN_AUTHORIZED_PRICE_CONFIGURATION",
            "clerk_entry": {
              "action": "EDIT_DRAFT",
              "control": "CHOOSE_FROM_PRODUCT_DIRECTORY",
              "confirmation": "SELECT_SKU_AND_SAVE",
              "can_configure_tier_price": false
            },
            "price_configuration": {
              "required": true,
              "semantic_reviewer": "Zhou",
              "technical_coordinator": "He",
              "executor": "AUTHORIZED_DATA_OPERATOR",
              "environment": "AUTHORIZED_CANDIDATE_ONLY",
              "execution_status": "NOT_RUN"
            }
          }
        },
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null
      }
    ],
    "conditions": [],
    "blocking_issues": [
      "LOW_CONFIDENCE_MATCH"
    ],
    "escalation_preview": [],
    "totals": {
      "order_total": null,
      "currency": "MYR",
      "is_complete": false
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "RESOLVE_ISSUE",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {
      "APPROVE_AND_GENERATE_DO": [
        "LOW_CONFIDENCE_MATCH"
      ],
      "SUBMIT_FOR_OWNER": [
        "LOW_CONFIDENCE_MATCH"
      ],
      "OWNER_APPROVE": [
        "LOW_CONFIDENCE_MATCH"
      ]
    },
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_CONDITION",
    "version": 1,
    "status": "DISAMBIGUATION_REQUIRED",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "🙂 2 bag Gula 1kg\n2 bag Garam 1kg\nkalau RM8.40 boleh?",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": "SAMPLE_GULA_1KG",
        "family_id": "FAM_GULA",
        "description": "Interface sample GULA_1KG",
        "requested_qty": 2,
        "confirmed_qty": null,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": "1kg",
        "grade": null,
        "tier_unit_price": "7.10",
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": "7.10",
        "subtotal_rm": "14.20",
        "match_source": "RAPIDFUZZ_FALLBACK",
        "source_span": "2 bag Gula 1kg",
        "span_start": 2,
        "span_end": 16,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 2,
            "end": 3,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 4,
            "end": 7,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "pack_size",
            "raw_text": "1kg",
            "start": 13,
            "end": 16,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": 30
      },
      {
        "line_id": "SAMPLE_L02",
        "client_line_ref": null,
        "sku_id": "SAMPLE_GARAM_1KG",
        "family_id": "FAM_GARAM",
        "description": "Interface sample GARAM_1KG",
        "requested_qty": 2,
        "confirmed_qty": null,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": "1kg",
        "grade": null,
        "tier_unit_price": "4.60",
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": "4.60",
        "subtotal_rm": "9.20",
        "match_source": "RAPIDFUZZ_FALLBACK",
        "source_span": "2 bag Garam 1kg",
        "span_start": 17,
        "span_end": 32,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 17,
            "end": 18,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 19,
            "end": 22,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "pack_size",
            "raw_text": "1kg",
            "start": 29,
            "end": 32,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": 30
      }
    ],
    "issues": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "CUSTOMER_CONDITION",
        "line_id": null,
        "span": "kalau RM8.40 boleh?",
        "span_start": 33,
        "span_end": 52,
        "candidate_line_ids": [
          "SAMPLE_L01",
          "SAMPLE_L02"
        ],
        "target_line_ids": [],
        "reason_code": null,
        "ask": "CLERK",
        "data_used": {
          "requested_amount": "8.40"
        },
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null,
        "condition_kind": "PRICE",
        "condition_scope": "UNKNOWN",
        "price_basis": "UNKNOWN",
        "requested_unit_price": null,
        "condition_id": "CND_6BAFF2E046E11A9F84B97079"
      }
    ],
    "conditions": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "CUSTOMER_CONDITION",
        "line_id": null,
        "span": "kalau RM8.40 boleh?",
        "span_start": 33,
        "span_end": 52,
        "candidate_line_ids": [
          "SAMPLE_L01",
          "SAMPLE_L02"
        ],
        "target_line_ids": [],
        "reason_code": null,
        "ask": "CLERK",
        "data_used": {
          "requested_amount": "8.40"
        },
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null,
        "condition_kind": "PRICE",
        "condition_scope": "UNKNOWN",
        "price_basis": "UNKNOWN",
        "requested_unit_price": null,
        "condition_id": "CND_6BAFF2E046E11A9F84B97079"
      }
    ],
    "blocking_issues": [
      "CUSTOMER_CONDITION"
    ],
    "escalation_preview": [],
    "totals": {
      "order_total": "23.40",
      "currency": "MYR",
      "is_complete": true
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "RESOLVE_ISSUE",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {
      "APPROVE_AND_GENERATE_DO": [
        "CUSTOMER_CONDITION"
      ],
      "SUBMIT_FOR_OWNER": [
        "CUSTOMER_CONDITION"
      ],
      "OWNER_APPROVE": [
        "CUSTOMER_CONDITION"
      ]
    },
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_CONDITION",
    "version": 2,
    "status": "READY_FOR_APPROVAL",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "🙂 2 bag Gula 1kg\n2 bag Garam 1kg\nkalau RM8.40 boleh?",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": "SAMPLE_GULA_1KG",
        "family_id": "FAM_GULA",
        "description": "Interface sample GULA_1KG",
        "requested_qty": 2,
        "confirmed_qty": 2,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": "1kg",
        "grade": null,
        "tier_unit_price": "7.10",
        "unit_price_override": "8.40",
        "override_reason": "Synthetic customer confirmation: unit price 8.40 applies to the selected Gula line only.",
        "effective_unit_price": "8.40",
        "subtotal_rm": "16.80",
        "match_source": "MANUAL_SELECTED",
        "source_span": "2 bag Gula 1kg",
        "span_start": 2,
        "span_end": 16,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 2,
            "end": 3,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 4,
            "end": 7,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "pack_size",
            "raw_text": "1kg",
            "start": 13,
            "end": 16,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": 30
      },
      {
        "line_id": "SAMPLE_L02",
        "client_line_ref": null,
        "sku_id": "SAMPLE_GARAM_1KG",
        "family_id": "FAM_GARAM",
        "description": "Interface sample GARAM_1KG",
        "requested_qty": 2,
        "confirmed_qty": 2,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": "1kg",
        "grade": null,
        "tier_unit_price": "4.60",
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": "4.60",
        "subtotal_rm": "9.20",
        "match_source": "MANUAL_SELECTED",
        "source_span": "2 bag Garam 1kg",
        "span_start": 17,
        "span_end": 32,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 17,
            "end": 18,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 19,
            "end": 22,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "pack_size",
            "raw_text": "1kg",
            "start": 29,
            "end": 32,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": 30
      }
    ],
    "issues": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "CUSTOMER_CONDITION",
        "line_id": null,
        "span": "kalau RM8.40 boleh?",
        "span_start": 33,
        "span_end": 52,
        "candidate_line_ids": [
          "SAMPLE_L01",
          "SAMPLE_L02"
        ],
        "target_line_ids": [
          "SAMPLE_L01"
        ],
        "reason_code": null,
        "ask": "CLERK",
        "data_used": {
          "requested_amount": "8.40",
          "confirmed_unit_price": "8.40"
        },
        "blocking": true,
        "resolved": true,
        "resolution": "ACCEPT_REQUESTED_PRICE",
        "resolution_note": "Synthetic customer confirmation: unit price 8.40 applies to the selected Gula line only.",
        "auto_resolved_by": null,
        "condition_kind": "PRICE",
        "condition_scope": "UNKNOWN",
        "price_basis": "UNIT",
        "requested_unit_price": null,
        "condition_id": "CND_6BAFF2E046E11A9F84B97079"
      }
    ],
    "conditions": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "CUSTOMER_CONDITION",
        "line_id": null,
        "span": "kalau RM8.40 boleh?",
        "span_start": 33,
        "span_end": 52,
        "candidate_line_ids": [
          "SAMPLE_L01",
          "SAMPLE_L02"
        ],
        "target_line_ids": [
          "SAMPLE_L01"
        ],
        "reason_code": null,
        "ask": "CLERK",
        "data_used": {
          "requested_amount": "8.40",
          "confirmed_unit_price": "8.40"
        },
        "blocking": true,
        "resolved": true,
        "resolution": "ACCEPT_REQUESTED_PRICE",
        "resolution_note": "Synthetic customer confirmation: unit price 8.40 applies to the selected Gula line only.",
        "auto_resolved_by": null,
        "condition_kind": "PRICE",
        "condition_scope": "UNKNOWN",
        "price_basis": "UNIT",
        "requested_unit_price": null,
        "condition_id": "CND_6BAFF2E046E11A9F84B97079"
      }
    ],
    "blocking_issues": [],
    "escalation_preview": [],
    "totals": {
      "order_total": "26.00",
      "currency": "MYR",
      "is_complete": true
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "APPROVE_AND_GENERATE_DO",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {},
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  },
  {
    "draft_id": "SAMPLE_R08_CONDITION",
    "version": 1,
    "status": "DISAMBIGUATION_REQUIRED",
    "customer_id": "SAMPLE_CUSTOMER",
    "customer": {
      "customer_id": "SAMPLE_CUSTOMER",
      "name": "Interface sample customer",
      "tier": "A",
      "credit_flag": "NONE",
      "has_credit_notice": false,
      "phone_e164": null
    },
    "masked_message": "🙂 2 bag Gula 1kg\n2 bag Garam 1kg\nkalau RM8.40 boleh?",
    "ai_mode": "FALLBACK",
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "client_line_ref": null,
        "sku_id": "SAMPLE_GULA_1KG",
        "family_id": "FAM_GULA",
        "description": "Interface sample GULA_1KG",
        "requested_qty": 2,
        "confirmed_qty": null,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": "1kg",
        "grade": null,
        "tier_unit_price": "7.10",
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": "7.10",
        "subtotal_rm": "14.20",
        "match_source": "RAPIDFUZZ_FALLBACK",
        "source_span": "2 bag Gula 1kg",
        "span_start": 2,
        "span_end": 16,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 2,
            "end": 3,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 4,
            "end": 7,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "pack_size",
            "raw_text": "1kg",
            "start": 13,
            "end": 16,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": 30
      },
      {
        "line_id": "SAMPLE_L02",
        "client_line_ref": null,
        "sku_id": "SAMPLE_GARAM_1KG",
        "family_id": "FAM_GARAM",
        "description": "Interface sample GARAM_1KG",
        "requested_qty": 2,
        "confirmed_qty": null,
        "effective_qty": 2,
        "uom": "bag",
        "pack_size": "1kg",
        "grade": null,
        "tier_unit_price": "4.60",
        "unit_price_override": null,
        "override_reason": null,
        "effective_unit_price": "4.60",
        "subtotal_rm": "9.20",
        "match_source": "RAPIDFUZZ_FALLBACK",
        "source_span": "2 bag Garam 1kg",
        "span_start": 17,
        "span_end": 32,
        "field_evidence": [
          {
            "field": "qty",
            "raw_text": "2",
            "start": 17,
            "end": 18,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "uom",
            "raw_text": "bag",
            "start": 19,
            "end": 22,
            "normalizer_version": "field-evidence-v2"
          },
          {
            "field": "pack_size",
            "raw_text": "1kg",
            "start": 29,
            "end": 32,
            "normalizer_version": "field-evidence-v2"
          }
        ],
        "candidate_skus": [],
        "saved_alias": null,
        "available_qty": 30
      }
    ],
    "issues": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "CUSTOMER_CONDITION",
        "line_id": null,
        "span": "kalau RM8.40 boleh?",
        "span_start": 33,
        "span_end": 52,
        "candidate_line_ids": [
          "SAMPLE_L01",
          "SAMPLE_L02"
        ],
        "target_line_ids": [],
        "reason_code": null,
        "ask": "CLERK",
        "data_used": {
          "requested_amount": "8.40"
        },
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null,
        "condition_kind": "PRICE",
        "condition_scope": "UNKNOWN",
        "price_basis": "UNKNOWN",
        "requested_unit_price": null,
        "condition_id": "CND_6BAFF2E046E11A9F84B97079"
      }
    ],
    "conditions": [
      {
        "issue_id": "SAMPLE_I01",
        "code": "CUSTOMER_CONDITION",
        "line_id": null,
        "span": "kalau RM8.40 boleh?",
        "span_start": 33,
        "span_end": 52,
        "candidate_line_ids": [
          "SAMPLE_L01",
          "SAMPLE_L02"
        ],
        "target_line_ids": [],
        "reason_code": null,
        "ask": "CLERK",
        "data_used": {
          "requested_amount": "8.40"
        },
        "blocking": true,
        "resolved": false,
        "resolution": null,
        "resolution_note": null,
        "auto_resolved_by": null,
        "condition_kind": "PRICE",
        "condition_scope": "UNKNOWN",
        "price_basis": "UNKNOWN",
        "requested_unit_price": null,
        "condition_id": "CND_6BAFF2E046E11A9F84B97079"
      }
    ],
    "blocking_issues": [
      "CUSTOMER_CONDITION"
    ],
    "escalation_preview": [],
    "totals": {
      "order_total": "23.40",
      "currency": "MYR",
      "is_complete": true
    },
    "allowed_actions": [
      "EDIT_DRAFT",
      "RESOLVE_ISSUE",
      "CANCEL_DRAFT",
      "VIEW_ACTIVITY"
    ],
    "blocked_actions": {
      "APPROVE_AND_GENERATE_DO": [
        "CUSTOMER_CONDITION"
      ],
      "SUBMIT_FOR_OWNER": [
        "CUSTOMER_CONDITION"
      ],
      "OWNER_APPROVE": [
        "CUSTOMER_CONDITION"
      ]
    },
    "clarification_draft": null,
    "clarification_lang": null,
    "ignored_spans": [],
    "disambiguations": [],
    "termination_reason": null,
    "terminated_by_user_id": null,
    "termination_note": null,
    "created_at": "2026-11-01T03:30:00+08:00",
    "updated_at": "2026-11-01T03:30:00+08:00",
    "do_number": null
  }
] satisfies S["OrderDraft"][];
export const saves = [
  {
    "expected_version": 1,
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "sku_id": "SAMPLE_GULA_1KG",
        "family_id": "FAM_GULA",
        "confirmed_qty": 2,
        "uom": "bag",
        "pack_size": "1kg",
        "grade": null,
        "match_source": "MANUAL_SELECTED",
        "save_to_alias_cache": false,
        "alias_scope": "CUSTOMER"
      }
    ],
    "deleted_line_ids": [],
    "resolutions": []
  },
  {
    "expected_version": 1,
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "sku_id": "SAMPLE_GULA_2KG",
        "family_id": "FAM_GULA",
        "confirmed_qty": 2,
        "uom": "bag",
        "pack_size": "2kg",
        "grade": null,
        "match_source": "MANUAL_SELECTED",
        "save_to_alias_cache": false,
        "alias_scope": "CUSTOMER"
      }
    ],
    "deleted_line_ids": [],
    "resolutions": []
  },
  {
    "expected_version": 1,
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "sku_id": "SAMPLE_BERAS_5KG",
        "family_id": "FAM_BERAS",
        "confirmed_qty": 2,
        "uom": "bag",
        "pack_size": "5kg",
        "grade": null,
        "match_source": "MANUAL_SELECTED",
        "save_to_alias_cache": false,
        "alias_scope": "CUSTOMER"
      }
    ],
    "deleted_line_ids": [],
    "resolutions": []
  },
  {
    "expected_version": 1,
    "lines": [
      {
        "client_line_ref": "SAMPLE_MANUAL_01",
        "sku_id": "SAMPLE_GARAM_1KG",
        "family_id": "FAM_GARAM",
        "confirmed_qty": 3,
        "uom": "bag",
        "pack_size": "1kg",
        "grade": null,
        "match_source": "MANUAL_SELECTED",
        "save_to_alias_cache": false,
        "alias_scope": "CUSTOMER"
      }
    ],
    "deleted_line_ids": [],
    "resolutions": []
  },
  {
    "expected_version": 1,
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "sku_id": "SAMPLE_GULA_2KG",
        "family_id": "FAM_GULA",
        "confirmed_qty": 2,
        "uom": "bag",
        "pack_size": "2kg",
        "grade": null,
        "match_source": "MANUAL_SELECTED",
        "save_to_alias_cache": false,
        "alias_scope": "CUSTOMER"
      }
    ],
    "deleted_line_ids": [],
    "resolutions": []
  },
  {
    "expected_version": 1,
    "lines": [
      {
        "line_id": "SAMPLE_L01",
        "sku_id": "SAMPLE_GULA_1KG",
        "family_id": "FAM_GULA",
        "confirmed_qty": 2,
        "uom": "bag",
        "pack_size": "1kg",
        "grade": null,
        "match_source": "MANUAL_SELECTED",
        "save_to_alias_cache": false,
        "alias_scope": "CUSTOMER",
        "unit_price_override": "8.40",
        "override_reason": "Synthetic customer confirmation: unit price 8.40 applies to the selected Gula line only."
      },
      {
        "line_id": "SAMPLE_L02",
        "sku_id": "SAMPLE_GARAM_1KG",
        "family_id": "FAM_GARAM",
        "confirmed_qty": 2,
        "uom": "bag",
        "pack_size": "1kg",
        "grade": null,
        "match_source": "MANUAL_SELECTED",
        "save_to_alias_cache": false,
        "alias_scope": "CUSTOMER"
      }
    ],
    "deleted_line_ids": [],
    "resolutions": [
      {
        "issue_id": "SAMPLE_I01",
        "choice": "ACCEPT_REQUESTED_PRICE",
        "target_line_ids": [
          "SAMPLE_L01"
        ],
        "confirmed_unit_price": "8.40",
        "price_basis": "UNIT",
        "note": "Synthetic customer confirmation: unit price 8.40 applies to the selected Gula line only."
      }
    ]
  }
] satisfies S["SaveLinesRequest"][];
